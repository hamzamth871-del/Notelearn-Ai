import { corsHeaders } from '../_shared/cors.ts';

// Extract YouTube video ID from any YouTube URL format
function extractYouTubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /[?&]v=([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m?.[1]) return m[1];
  }
  return null;
}

// Try fetching YouTube transcript via multiple methods, also try to get timestamps
async function fetchYouTubeTranscript(videoId: string): Promise<{ text: string; hasTimestamps: boolean }> {
  // Method 1: YoutubeTranscript API (free, no key required)
  try {
    console.log('Method 1: Trying youtubetranscript.com API for', videoId);
    const res = await fetch(`https://youtubetranscript.com/?server_vid2=${videoId}`, {
      headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' },
      signal: AbortSignal.timeout(10000),
    });
    if (res.ok) {
      const text = await res.text();
      if (text && text.length > 200) {
        const stripped = text.replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim();
        if (stripped.length > 100) {
          console.log('Method 1 success, length:', stripped.length);
          return { text: stripped, hasTimestamps: false };
        }
      }
    }
  } catch (e) { console.log('Method 1 failed:', e); }

  // Method 2: Jina Reader on YouTube URL
  try {
    console.log('Method 2: Trying Jina Reader for video', videoId);
    const jinaUrl = `https://r.jina.ai/https://www.youtube.com/watch?v=${videoId}`;
    const res = await fetch(jinaUrl, {
      headers: { 'Accept': 'text/plain', 'X-Return-Format': 'markdown' },
      signal: AbortSignal.timeout(20000),
    });
    if (res.ok) {
      const text = await res.text();
      if (text && text.trim().length > 200) {
        console.log('Method 2 success, length:', text.length);
        return { text: text.slice(0, 18000), hasTimestamps: false };
      }
    }
  } catch (e) { console.log('Method 2 failed:', e); }

  // Method 3: Fetch YouTube page HTML and extract captions with timestamps
  try {
    console.log('Method 3: Fetching YouTube page HTML for', videoId);
    const res = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      },
      signal: AbortSignal.timeout(15000),
    });
    if (res.ok) {
      const html = await res.text();
      const titleMatch = html.match(/<title>([^<]+)<\/title>/);
      const videoTitle = titleMatch ? titleMatch[1].replace(' - YouTube', '').trim() : '';
      const descMatch = html.match(/"shortDescription":"((?:[^"\\]|\\.)+)"/);
      const description = descMatch ? descMatch[1].replace(/\\n/g, '\n').replace(/\\u0026/g, '&').replace(/\\"/g, '"').slice(0, 3000) : '';

      // Try to extract timed captions
      const captionMatch = html.match(/"captionTracks":\[\{"baseUrl":"([^"]+)"/);
      if (captionMatch) {
        try {
          const captionUrl = captionMatch[1].replace(/\\u0026/g, '&');
          const captionRes = await fetch(captionUrl, { signal: AbortSignal.timeout(10000) });
          if (captionRes.ok) {
            const xml = await captionRes.text();
            // Parse timestamps from XML caption format: <text start="12.5" dur="3.2">...</text>
            const timedLines: string[] = [];
            const timedRegex = /<text start="([\d.]+)"[^>]*>([^<]+)<\/text>/g;
            let m;
            while ((m = timedRegex.exec(xml)) !== null) {
              const seconds = parseFloat(m[1]);
              const mins = Math.floor(seconds / 60);
              const secs = Math.floor(seconds % 60);
              const timestamp = `[${mins}:${secs.toString().padStart(2, '0')}]`;
              const text = m[2].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").trim();
              timedLines.push(`${timestamp} ${text}`);
            }
            if (timedLines.length > 10) {
              const timedTranscript = timedLines.join('\n');
              console.log('Method 3 timed caption success, lines:', timedLines.length);
              return { text: `Title: ${videoTitle}\n\nTimestamped Transcript:\n${timedTranscript.slice(0, 18000)}`, hasTimestamps: true };
            }
            // Fallback: plain text strip
            const transcript = xml.replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
            if (transcript.length > 200) {
              return { text: `Title: ${videoTitle}\n\nTranscript:\n${transcript.slice(0, 18000)}`, hasTimestamps: false };
            }
          }
        } catch (e) { console.log('Caption fetch failed:', e); }
      }
      if (videoTitle || description) {
        return { text: `Video Title: ${videoTitle}\n\nVideo Description:\n${description}`, hasTimestamps: false };
      }
    }
  } catch (e) { console.log('Method 3 failed:', e); }

  return { text: '', hasTimestamps: false };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('ONSPACE_AI_API_KEY');
    const baseUrl = Deno.env.get('ONSPACE_AI_BASE_URL');

    const { text, source, title, url } = await req.json();

    let contentToAnalyze = text;
    let fetchedFromUrl = false;
    let hasTimestamps = false;

    // YouTube: use dedicated multi-method transcript fetcher
    if (source === 'youtube' && url) {
      const videoId = extractYouTubeId(url);
      console.log('YouTube video ID:', videoId);
      if (videoId) {
        const result = await fetchYouTubeTranscript(videoId);
        if (result.text && result.text.trim().length > 100) {
          contentToAnalyze = result.text;
          hasTimestamps = result.hasTimestamps;
          fetchedFromUrl = true;
          console.log('Got YouTube content, length:', contentToAnalyze.length, 'hasTimestamps:', hasTimestamps);
        } else {
          console.log('All YouTube transcript methods failed, using AI knowledge');
        }
      }
    }

    // Regular URL: use Jina Reader
    if (source === 'url' && url && !fetchedFromUrl) {
      try {
        console.log('Fetching URL content via Jina Reader:', url);
        const jinaUrl = `https://r.jina.ai/${url}`;
        const jinaResponse = await fetch(jinaUrl, {
          headers: { 'Accept': 'text/plain', 'X-Return-Format': 'markdown' },
          signal: AbortSignal.timeout(15000),
        });
        if (jinaResponse.ok) {
          const fetched = await jinaResponse.text();
          if (fetched && fetched.trim().length > 100) {
            contentToAnalyze = fetched.slice(0, 15000);
            fetchedFromUrl = true;
            console.log('Successfully fetched URL content, length:', contentToAnalyze.length);
          }
        }
      } catch (fetchErr) {
        console.log('Jina fetch failed, falling back to AI knowledge:', fetchErr);
      }
    }

    if (!contentToAnalyze || contentToAnalyze.trim().length < 10) {
      return new Response(
        JSON.stringify({ error: 'Not enough content to generate notes from.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // ─── System Prompt (with enhanced output schema) ──────────────────────────
    const isYouTube = source === 'youtube';

    const systemPrompt = `You are an expert AI study assistant that converts raw study material into beautifully structured, student-friendly learning content.

Always respond with ONLY a valid JSON object matching this exact schema — no markdown, no code fences, no extra text:

{
  "title": "string (concise topic title, max 60 chars)",
  "summary": "string (2–3 sentence overview of the material)",
  "sections": [
    {
      "heading": "string",
      "points": ["string", "string"]
    }
  ],
  "keyPoints": ["string", "string"],
  "definitions": [
    { "term": "string", "definition": "string (simple, clear explanation)" }
  ],${isYouTube ? `
  "keyMoments": [
    { "timestamp": "string (e.g. '0:00' or '5:32')", "topic": "string (short title)", "description": "string (what is discussed)" }
  ],` : ''}
  "flashcards": [
    { "front": "string (question or term)", "back": "string (answer or definition)" }
  ],
  "quizQuestions": [
    {
      "type": "multiple-choice",
      "question": "string",
      "options": ["A) option", "B) option", "C) option", "D) option"],
      "correctAnswer": "string (must match one option exactly)",
      "explanation": "string"
    }
  ]
}

Rules:
- sections: 4–7 sections, each with 3–8 bullet points. Plain text, no markdown.
- keyPoints: 5–10 most critical takeaways from the material. One sentence each.
- definitions: 5–10 important terms with simple, student-friendly definitions.${isYouTube ? `
- keyMoments: 4–8 key moments with timestamps. If transcript has [MM:SS] markers use them; otherwise estimate reasonable timestamps based on topic progression. Always include at least 4 key moments.` : ''}
- flashcards: 6–10 cards covering key terms and concepts.
- quizQuestions: 5–8 questions (mix of multiple-choice and short-answer). For short-answer, omit "options".
- All text must be concise, clear, and exam-focused.
- Output ONLY the JSON object, nothing else.`;

    // ─── User Prompt ──────────────────────────────────────────────────────────
    let userPrompt = '';

    if (fetchedFromUrl && isYouTube) {
      const timestampNote = hasTimestamps
        ? 'The transcript includes [MM:SS] timestamps — use them for keyMoments.'
        : 'Estimate reasonable timestamps for keyMoments based on topic progression through the video.';
      userPrompt = `Analyze this YouTube video content thoroughly and generate comprehensive, student-friendly study materials.

Video URL: ${url}
${timestampNote}

Video Content / Transcript:
${contentToAnalyze}

Generate detailed, well-organized educational content based on the actual video above. Include accurate timestamps in keyMoments wherever possible.`;
    } else if (fetchedFromUrl) {
      userPrompt = `Analyze the following content fetched from a URL and generate comprehensive structured study materials:

${contentToAnalyze}

Generate detailed, student-friendly notes covering all key topics, concepts, and information.`;
    } else if (isYouTube || source === 'url') {
      userPrompt = `Generate comprehensive, detailed study materials about the topic from this URL: ${url}

The topic/content to cover: ${text}

Based on your knowledge of this topic, create thorough educational content covering core concepts, key theories, important facts, and real-world applications.${isYouTube ? ' For keyMoments, estimate reasonable timestamps assuming a ~10–20 minute video.' : ''}`;
    } else if (source === 'pdf') {
      userPrompt = `Analyze the following PDF document content and generate comprehensive, student-friendly study materials.

Clean up any noise (page numbers, headers, footers) and focus on the educational content.

Document Content:
${contentToAnalyze.slice(0, 14000)}

Generate structured notes, key points, definitions, flashcards, and quiz questions suitable for revision and exam preparation.`;
    } else {
      userPrompt = `Study material (source: ${source || 'text'}):

${contentToAnalyze.slice(0, 14000)}

Generate comprehensive structured notes, key points, definitions, flashcards, and quiz questions for this material.`;
    }

    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('AI API error:', errText);
      return new Response(
        JSON.stringify({ error: `AI error: ${errText}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    const rawContent = data.choices?.[0]?.message?.content ?? '';
    console.log('Raw AI response (first 500):', rawContent.slice(0, 500));

    let cleaned = rawContent.trim();
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (jsonMatch) cleaned = jsonMatch[0];

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (e) {
      console.error('JSON parse error:', e, 'Raw:', rawContent.slice(0, 300));
      return new Response(
        JSON.stringify({ error: 'Failed to parse AI response as JSON. Please try again.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, data: parsed }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('generate-notes error:', err);
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
