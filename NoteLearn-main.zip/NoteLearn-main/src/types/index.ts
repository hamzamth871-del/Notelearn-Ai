export interface KeyMoment {
  timestamp: string;
  topic: string;
  description: string;
}

export interface Definition {
  term: string;
  definition: string;
}

export interface Note {
  id: string;
  title: string;
  subject: string;
  subjectId: string;
  content: NoteContent;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  source: 'pdf' | 'youtube' | 'audio' | 'lecture' | 'manual' | 'text';
  summary?: string;
  flashcards?: Flashcard[];
  quizQuestions?: QuizQuestion[];
  keyPoints?: string[];
  definitions?: Definition[];
  keyMoments?: KeyMoment[];
}

export interface NoteContent {
  sections: NoteSection[];
}

export interface NoteSection {
  heading: string;
  points: string[];
  table?: TableData;
}

export interface TableData {
  headers: string[];
  rows: string[][];
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  nextReview?: string;
}

export interface QuizQuestion {
  id: string;
  type: 'multiple-choice' | 'short-answer';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export interface Subject {
  id: string;
  name: string;
  color: string;
  icon: string;
  noteCount: number;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}
