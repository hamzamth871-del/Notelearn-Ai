import type { Note, Subject, Flashcard, QuizQuestion } from '@/types';

export const mockSubjects: Subject[] = [
  { id: 's1', name: 'Biology', color: '#22C55E', icon: '🧬', noteCount: 8, createdAt: '2026-03-01' },
  { id: 's2', name: 'History', color: '#F59E0B', icon: '📜', noteCount: 5, createdAt: '2026-03-05' },
  { id: 's3', name: 'Mathematics', color: '#3B82F6', icon: '📐', noteCount: 12, createdAt: '2026-03-10' },
  { id: 's4', name: 'Computer Science', color: '#FF6A00', icon: '💻', noteCount: 9, createdAt: '2026-03-15' },
  { id: 's5', name: 'Physics', color: '#8B5CF6', icon: '⚛️', noteCount: 6, createdAt: '2026-03-20' },
];

export const mockFlashcards: Flashcard[] = [
  { id: 'f1', front: 'What is Photosynthesis?', back: 'The process by which plants convert sunlight, CO₂, and water into glucose and oxygen using chlorophyll.', difficulty: 'easy' },
  { id: 'f2', front: 'Define Mitosis', back: 'Cell division resulting in two genetically identical daughter cells, each with the same number of chromosomes as the parent cell.', difficulty: 'medium' },
  { id: 'f3', front: 'What is DNA?', back: 'Deoxyribonucleic acid — a double-helix molecule carrying genetic instructions for growth, development, and reproduction.', difficulty: 'easy' },
  { id: 'f4', front: 'What is the role of ATP?', back: 'Adenosine triphosphate is the primary energy carrier molecule in cells, releasing energy when broken down to ADP.', difficulty: 'hard' },
  { id: 'f5', front: 'Explain Natural Selection', back: 'The mechanism by which individuals with favorable traits survive and reproduce more successfully, passing traits to offspring over generations.', difficulty: 'medium' },
];

export const mockQuizQuestions: QuizQuestion[] = [
  {
    id: 'q1',
    type: 'multiple-choice',
    question: 'Which organelle is responsible for photosynthesis?',
    options: ['Mitochondria', 'Chloroplast', 'Nucleus', 'Ribosome'],
    correctAnswer: 'Chloroplast',
    explanation: 'Chloroplasts contain chlorophyll, the pigment that captures sunlight to power photosynthesis. Mitochondria handle cellular respiration instead.'
  },
  {
    id: 'q2',
    type: 'multiple-choice',
    question: 'How many chromosomes do human somatic cells have?',
    options: ['23', '46', '92', '48'],
    correctAnswer: '46',
    explanation: 'Human somatic (body) cells are diploid and contain 46 chromosomes (23 pairs). Gametes (sperm/eggs) are haploid with 23 chromosomes.'
  },
  {
    id: 'q3',
    type: 'multiple-choice',
    question: 'What process converts glucose to pyruvate?',
    options: ['Krebs Cycle', 'Glycolysis', 'Electron Transport', 'Fermentation'],
    correctAnswer: 'Glycolysis',
    explanation: 'Glycolysis occurs in the cytoplasm and breaks down glucose (6C) into two pyruvate molecules (3C each), producing 2 ATP and 2 NADH.'
  },
  {
    id: 'q4',
    type: 'short-answer',
    question: 'What are the four bases found in DNA?',
    options: [],
    correctAnswer: 'Adenine, Thymine, Guanine, Cytosine',
    explanation: 'DNA contains four nitrogenous bases: Adenine (A) pairs with Thymine (T), and Guanine (G) pairs with Cytosine (C). In RNA, Uracil replaces Thymine.'
  },
];

export const mockNotes: Note[] = [
  {
    id: 'n1',
    title: 'Cell Biology: Fundamentals',
    subject: 'Biology',
    subjectId: 's1',
    tags: ['cells', 'biology', 'organelles'],
    source: 'pdf',
    createdAt: '2026-04-01T10:00:00Z',
    updatedAt: '2026-04-01T10:00:00Z',
    summary: 'An overview of cell structure, organelles, and their functions in both prokaryotic and eukaryotic organisms.',
    flashcards: mockFlashcards,
    quizQuestions: mockQuizQuestions,
    content: {
      sections: [
        {
          heading: '🔬 Cell Types',
          points: [
            'Prokaryotic cells: No membrane-bound nucleus (bacteria, archaea)',
            'Eukaryotic cells: Membrane-bound nucleus (animals, plants, fungi)',
            'Average human cell diameter: 10–100 micrometers',
            'All cells share: plasma membrane, cytoplasm, DNA, ribosomes',
          ]
        },
        {
          heading: '⚙️ Key Organelles & Functions',
          points: [
            'Nucleus: Houses genetic material (DNA), controls cell activities',
            'Mitochondria: "Powerhouse" — produces ATP via cellular respiration',
            'Chloroplast (plants): Site of photosynthesis, contains chlorophyll',
            'Endoplasmic Reticulum (ER): Rough ER synthesizes proteins; Smooth ER lipid synthesis',
            'Golgi Apparatus: Modifies, sorts, packages proteins for secretion',
            'Lysosomes: Contain digestive enzymes, break down cellular waste',
            'Ribosomes: Translate mRNA into proteins (free or ER-bound)',
          ]
        },
        {
          heading: '⚡ Cell Processes',
          points: [
            'Photosynthesis: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂',
            'Cellular Respiration: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP',
            'Mitosis: PMAT — Prophase, Metaphase, Anaphase, Telophase',
            'Active Transport: Moves molecules against gradient, requires ATP',
          ]
        },
        {
          heading: '📊 Comparison Table',
          points: [],
          table: {
            headers: ['Feature', 'Prokaryote', 'Eukaryote'],
            rows: [
              ['Nucleus', 'Absent', 'Present'],
              ['Size', '1–10 µm', '10–100 µm'],
              ['Organelles', 'None (membrane-bound)', 'Yes'],
              ['DNA shape', 'Circular', 'Linear chromosomes'],
              ['Examples', 'Bacteria', 'Plants, Animals, Fungi'],
            ]
          }
        },
        {
          heading: '🎯 Key Terms to Remember',
          points: [
            'Homeostasis: Maintaining stable internal conditions',
            'Osmosis: Diffusion of water across a semi-permeable membrane',
            'Turgor Pressure: Pressure of cell contents against cell wall (plants)',
            'Apoptosis: Programmed cell death — essential for development',
          ]
        }
      ]
    }
  },
  {
    id: 'n2',
    title: 'World War II: Causes & Timeline',
    subject: 'History',
    subjectId: 's2',
    tags: ['WWII', 'history', 'war'],
    source: 'youtube',
    createdAt: '2026-04-02T14:00:00Z',
    updatedAt: '2026-04-02T14:00:00Z',
    summary: 'Key causes, major events, and consequences of World War II from 1939 to 1945.',
    flashcards: [],
    quizQuestions: [],
    content: {
      sections: [
        {
          heading: '📌 Primary Causes',
          points: [
            'Treaty of Versailles (1919): Harsh reparations humiliated Germany',
            'Rise of Fascism: Nazi Germany, Fascist Italy, Imperial Japan',
            'Great Depression: Economic crisis fueled extremist political movements',
            'Failure of Appeasement: Munich Agreement 1938 emboldened Hitler',
            'Invasion of Poland: Sept 1, 1939 — UK & France declared war on Germany',
          ]
        },
        {
          heading: '🗓️ Major Timeline Events',
          points: [
            '1939: Germany invades Poland; WWII officially begins',
            '1940: Fall of France; Battle of Britain; Blitz begins',
            '1941: Operation Barbarossa; Pearl Harbor; USA enters war',
            '1942: Battle of Stalingrad; El-Alamein; Midway (Pacific turning point)',
            '1944: D-Day (June 6) — Allied invasion of Normandy',
            '1945: VE Day (May 8); Atomic bombs on Japan; VJ Day (Aug 15)',
          ]
        }
      ]
    }
  },
  {
    id: 'n3',
    title: 'Machine Learning Fundamentals',
    subject: 'Computer Science',
    subjectId: 's4',
    tags: ['AI', 'ML', 'algorithms'],
    source: 'lecture',
    createdAt: '2026-04-03T09:00:00Z',
    updatedAt: '2026-04-03T09:00:00Z',
    summary: 'Core concepts of machine learning including supervised, unsupervised learning, and neural networks.',
    flashcards: [],
    quizQuestions: [],
    content: {
      sections: [
        {
          heading: '🤖 ML Categories',
          points: [
            'Supervised Learning: Labeled training data (regression, classification)',
            'Unsupervised Learning: Unlabeled data, find patterns (clustering, PCA)',
            'Reinforcement Learning: Agent learns via rewards/penalties',
            'Semi-supervised: Mix of labeled and unlabeled data',
          ]
        },
        {
          heading: '🧠 Key Algorithms',
          points: [
            'Linear Regression: Predict continuous values using line of best fit',
            'Decision Trees: Tree-like model of decisions and outcomes',
            'Random Forest: Ensemble of decision trees to reduce overfitting',
            'SVM: Find optimal hyperplane separating classes',
            'Neural Networks: Layers of interconnected nodes mimicking the brain',
          ]
        }
      ]
    }
  },
];

export const aiResponses: Record<string, string> = {
  default: "I've analyzed your notes and I'm ready to help! Ask me anything about the content, and I'll explain concepts clearly or test your knowledge.",
  explain: "Let me break that down simply for you. Think of it as a three-step process...",
  quiz: "Great idea! Let's test what you know. Here's a question based on your notes:",
  summary: "Here's a concise summary of the key points from your notes:",
};

export const chatAIResponses = [
  "Based on your Cell Biology notes, photosynthesis occurs in the **chloroplasts** — specifically in the thylakoid membranes where the light reactions happen, and the stroma where the Calvin cycle takes place. 🌿",
  "Great question! Mitosis and meiosis are both cell division processes, but with key differences: Mitosis produces **2 identical diploid cells** (for growth/repair), while meiosis produces **4 genetically unique haploid cells** (for reproduction).",
  "The powerhouse analogy for mitochondria comes from ATP production via the **electron transport chain**. It's like a tiny factory — glucose goes in, gets processed through glycolysis and the Krebs cycle, and ATP energy comes out.",
  "To remember the phases of mitosis, use **PMAT**: **P**rophase (chromosomes condense), **M**etaphase (line up at center), **A**naphase (pulled apart), **T**elophase (two nuclei form). ✅",
  "DNA replication follows the **semi-conservative model** — each new DNA molecule has one original strand and one newly synthesized strand. The enzyme **DNA polymerase** does the actual copying!",
];
