import { supabase } from '@/lib/supabase';
import type { Note, Flashcard, QuizQuestion } from '@/types';

// Map DB row → Note
function mapRow(row: Record<string, unknown>): Note {
  const content = (row.content as { sections?: unknown[] }) || {};
  return {
    id: row.id as string,
    title: row.title as string,
    subject: (row.subject_name as string) || '',
    subjectId: (row.subject_id as string) || '',
    content: {
      sections: (content.sections || []) as Note['content']['sections'],
    },
    tags: (row.tags as string[]) || [],
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
    source: (row.source as Note['source']) || 'text',
    summary: (row.summary as string) || '',
    flashcards: (row.flashcards as Flashcard[]) || [],
    quizQuestions: (row.quiz_questions as QuizQuestion[]) || [],
  };
}

export async function getNotes(userId: string): Promise<Note[]> {
  const { data, error } = await supabase
    .from('notes')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map(mapRow);
}

export async function getNotesBySubject(userId: string, subjectId: string): Promise<Note[]> {
  const { data, error } = await supabase
    .from('notes')
    .select('*')
    .eq('user_id', userId)
    .eq('subject_id', subjectId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map(mapRow);
}

export async function getNoteById(id: string): Promise<Note | null> {
  const { data, error } = await supabase
    .from('notes')
    .select('*')
    .eq('id', id)
    .single();
  if (error || !data) return null;
  return mapRow(data);
}

export async function saveNote(userId: string, note: Note): Promise<Note> {
  const payload = {
    user_id: userId,
    subject_id: note.subjectId || null,
    title: note.title,
    subject_name: note.subject || '',
    source: note.source,
    summary: note.summary || '',
    content: { sections: note.content.sections },
    flashcards: note.flashcards || [],
    quiz_questions: note.quizQuestions || [],
    tags: note.tags || [],
  };

  const { data, error } = await supabase
    .from('notes')
    .insert(payload)
    .select()
    .single();
  if (error) throw error;
  return mapRow(data);
}

export async function deleteNote(noteId: string): Promise<void> {
  const { error } = await supabase.from('notes').delete().eq('id', noteId);
  if (error) throw error;
}

export async function moveNote(noteId: string, newSubjectId: string, newSubjectName: string): Promise<void> {
  const { error } = await supabase
    .from('notes')
    .update({ subject_id: newSubjectId || null, subject_name: newSubjectName })
    .eq('id', noteId);
  if (error) throw error;
}

export async function incrementSubjectNoteCount(subjectId: string): Promise<void> {
  // Use rpc or just re-fetch. Since we don't have an rpc, do a manual increment.
  const { data } = await supabase.from('subjects').select('note_count').eq('id', subjectId).single();
  if (data) {
    await supabase.from('subjects').update({ note_count: (data.note_count || 0) + 1 }).eq('id', subjectId);
  }
}

export async function updateNote(noteId: string, updates: Partial<Pick<Note, 'title' | 'summary' | 'content' | 'tags'>>): Promise<void> {
  const payload: Record<string, unknown> = {};
  if (updates.title !== undefined) payload.title = updates.title;
  if (updates.summary !== undefined) payload.summary = updates.summary;
  if (updates.content !== undefined) payload.content = { sections: updates.content.sections };
  if (updates.tags !== undefined) payload.tags = updates.tags;
  payload.updated_at = new Date().toISOString();
  const { error } = await supabase.from('notes').update(payload).eq('id', noteId);
  if (error) throw error;
}

export async function decrementSubjectNoteCount(subjectId: string): Promise<void> {
  const { data } = await supabase.from('subjects').select('note_count').eq('id', subjectId).single();
  if (data) {
    const count = Math.max(0, (data.note_count || 0) - 1);
    await supabase.from('subjects').update({ note_count: count }).eq('id', subjectId);
  }
}
