import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import type { User as SupabaseUser } from '@supabase/supabase-js';

export interface User {
  id: string;
  name: string;
  email: string;
  createdAt: string;
  avatar?: string;
}

export interface Subject {
  id: string;
  user_id?: string;
  name: string;
  color: string;
  icon: string;
  noteCount: number;
  note_count?: number;
  createdAt: string;
  created_at?: string;
}

function mapSupabaseUser(u: SupabaseUser): User {
  return {
    id: u.id,
    name: u.user_metadata?.full_name || u.user_metadata?.name || u.email!.split('@')[0],
    email: u.email!,
    createdAt: u.created_at,
    avatar: u.user_metadata?.avatar_url,
  };
}

let authListeners: Array<(user: User | null) => void> = [];
let currentUser: User | null = null;

function notifyListeners(user: User | null) {
  currentUser = user;
  authListeners.forEach(fn => fn(user));
}

// Initialize session once
let initialized = false;
let initLoading = true;
let initListeners: Array<(loading: boolean) => void> = [];

function notifyInitListeners(loading: boolean) {
  initLoading = loading;
  initListeners.forEach(fn => fn(loading));
}

if (!initialized) {
  initialized = true;
  supabase.auth.getSession().then(({ data: { session } }) => {
    if (session?.user) notifyListeners(mapSupabaseUser(session.user));
    notifyInitListeners(false);
  });

  supabase.auth.onAuthStateChange((_event, session) => {
    if (session?.user) notifyListeners(mapSupabaseUser(session.user));
    else notifyListeners(null);
    notifyInitListeners(false);
  });
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(currentUser);
  const [loading, setLoading] = useState(initLoading);

  useEffect(() => {
    const userListener = (u: User | null) => setUser(u);
    const loadingListener = (l: boolean) => setLoading(l);
    authListeners.push(userListener);
    initListeners.push(loadingListener);
    // Sync current state
    setUser(currentUser);
    setLoading(initLoading);
    return () => {
      authListeners = authListeners.filter(fn => fn !== userListener);
      initListeners = initListeners.filter(fn => fn !== loadingListener);
    };
  }, []);

  const sendOtp = async (email: string) => {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { shouldCreateUser: true },
    });
    if (error) throw error;
  };

  const verifyOtpAndSetPassword = async (email: string, token: string, password: string, name: string) => {
    const { data, error } = await supabase.auth.verifyOtp({ email, token, type: 'email' });
    if (error) throw error;

    const { data: updateData, error: updateError } = await supabase.auth.updateUser({
      password,
      data: { full_name: name },
    });
    if (updateError) throw updateError;
    return updateData.user!;
  };

  const signInWithPassword = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data.user;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    notifyListeners(null);
  };

  const updateAvatar = async (avatarUrl: string) => {
    const { error } = await supabase.auth.updateUser({ data: { avatar_url: avatarUrl } });
    if (error) throw error;
    if (currentUser) {
      const updated = { ...currentUser, avatar: avatarUrl };
      notifyListeners(updated);
    }
  };

  const updateName = async (name: string) => {
    const { error } = await supabase.auth.updateUser({ data: { full_name: name } });
    if (error) throw error;
    if (currentUser) {
      const updated = { ...currentUser, name };
      notifyListeners(updated);
    }
  };

  return { user, loading, sendOtp, verifyOtpAndSetPassword, signInWithPassword, signOut, updateAvatar, updateName };
}

// Subject CRUD (Supabase DB)
export async function getSubjects(userId: string): Promise<Subject[]> {
  const { data, error } = await supabase
    .from('subjects')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data || []).map(s => ({
    id: s.id,
    user_id: s.user_id,
    name: s.name,
    color: s.color,
    icon: s.icon,
    noteCount: s.note_count || 0,
    createdAt: s.created_at,
  }));
}

export async function createSubject(userId: string, subject: Omit<Subject, 'id' | 'createdAt' | 'user_id'>): Promise<Subject> {
  const { data, error } = await supabase
    .from('subjects')
    .insert({
      user_id: userId,
      name: subject.name,
      color: subject.color,
      icon: subject.icon,
      note_count: 0,
    })
    .select()
    .single();
  if (error) throw error;
  return {
    id: data.id,
    user_id: data.user_id,
    name: data.name,
    color: data.color,
    icon: data.icon,
    noteCount: data.note_count || 0,
    createdAt: data.created_at,
  };
}

export async function deleteSubject(subjectId: string): Promise<void> {
  const { error } = await supabase.from('subjects').delete().eq('id', subjectId);
  if (error) throw error;
}
