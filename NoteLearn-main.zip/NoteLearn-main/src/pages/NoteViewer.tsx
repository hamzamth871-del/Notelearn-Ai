
import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, BookOpen, Brain, MessageSquare, Sparkles,
  FileText, Clock, Tag, ChevronRight, AlertCircle, Loader2, Trash2,
  Edit3, Save, X, Plus, Check, GripVertical
} from 'lucide-react';
import type { Note, NoteSection } from '@/types';
import { getNoteById, deleteNote, updateNote } from '@/lib/noteStorage';
import FlashcardModal from '@/components/features/FlashcardModal';
import QuizModal from '@/components/features/QuizModal';
import { toast } from 'sonner';

// ─── Editable Section ─────────────────────────────────────────────────────────
function EditableSection({
  section, index, onUpdate, onDelete,
}: {
  section: NoteSection;
  index: number;
  onUpdate: (i: number, updated: NoteSection) => void;
  onDelete: (i: number) => void;
}) {
  const [heading, setHeading] = useState(section.heading);
  const [points, setPoints] = useState<string[]>(section.points);

  useEffect(() => {
    // The previous 'section' dependency was causing an infinite loop due to object reference change
    // Destructure properties from 'section' that are actually used to avoid unnecessary re-runs
    // or rely on the 'heading' and 'points' state which are derived from 'section'
    onUpdate(index, { heading, points: points.filter(p => p.trim()) });
  }, [heading, points, index, onUpdate]);

  const updatePoint = (pi: number, val: string) => {
    setPoints(prev => prev.map((p, i) => i === pi ? val : p));
  };

  const addPoint = () => setPoints(prev => [...prev, '']);

  const deletePoint = (pi: number) => {
    setPoints(prev => prev.filter((_, i) => i !== pi));
  };

  return (
    <div className="rounded-2xl overflow-hidden mb-4" style={{ border: '1px solid rgba(255,106,0,0.2)', background: 'rgba(255,106,0,0.02)' }}>
      <div className="flex items-center gap-3 px-4 py-3" style={{ borderBottom: '1px solid rgba(255,106,0,0.1)' }}>
        <GripVertical className="w-4 h-4 flex-shrink-0" style={{ color: '#444' }} />
        <input
          value={heading}
          onChange={e => setHeading(e.target.value)}
          className="flex-1 bg-transparent text-base font-bold text-white outline-none"
          placeholder="Section heading..."
        />
        <button
          onClick={() => onDelete(index)}
          className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors hover:bg-red-500/20"
          style={{ color: '#666' }}
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="px-4 py-3 space-y-2">
        {points.map((pt, pi) => (
          <div key={pi} className="flex items-start gap-2 group">
            <span className="w-1.5 h-1.5 rounded-full mt-2.5 flex-shrink-0" style={{ background: '#FF6A00' }} />
            <textarea
              value={pt}
              onChange={e => updatePoint(pi, e.target.value)}
              rows={1}
              className="flex-1 bg-transparent text-sm outline-none resize-none leading-relaxed"
              style={{ color: '#D0D0D0' }}
              placeholder="Bullet point..."
              onInput={e => {
                const t = e.target as HTMLTextAreaElement;
                t.style.height = 'auto';
                t.style.height = t.scrollHeight + 'px';
              }}
            />
            <button
              onClick={() => deletePoint(pi)}
              className="w-5 h-5 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 mt-1"
              style={{ color: '#666' }}
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        <button
          onClick={addPoint}
          className="flex items-center gap-2 text-xs mt-2 px-2 py-1 rounded-lg transition-colors"
          style={{ color: '#FF6A00', background: 'rgba(255,106,0,0.08)' }}
        >
          <Plus className="w-3 h-3" />
          Add point
        </button>
      </div>
    </div>
  );
}

export default function NoteViewer() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [note, setNote] = useState<Note | null>(null);
  const [loading, setLoading] = useState(true);
  const [showFlashcards, setShowFlashcards] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [activeSection, setActiveSection] = useState(0);
  const [deleting, setDeleting] = useState(false);

  // Edit mode
  const [editing, setEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editSummary, setEditSummary] = useState('');
  const [editSections, setEditSections] = useState<NoteSection[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) { setLoading(false); return; }
    getNoteById(id).then(found => {
      setNote(found);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [id]);

  const enterEditMode = () => {
    if (!note) return;
    setEditTitle(note.title);
    setEditSummary(note.summary || '');
    setEditSections(note.content.sections.map(s => ({ ...s, points: [...s.points] })));
    setEditing(true);
  };

  const cancelEdit = () => setEditing(false);

  const handleSaveEdit = async () => {
    if (!note) return;
    setSaving(true);
    try {
      const cleanSections = editSections.map(s => ({
        ...s,
        points: s.points.filter(p => p.trim()),
      })).filter(s => s.heading.trim());

      await updateNote(note.id, {
        title: editTitle.trim() || note.title,
        summary: editSummary,
        content: { sections: cleanSections },
      });

      setNote(prev => prev ? {
        ...prev,
        title: editTitle.trim() || prev.title,
        summary: editSummary,
        content: { sections: cleanSections },
      } : prev);

      setEditing(false);
      toast.success('Note updated!');
    } catch {
      toast.error('Failed to save changes.');
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateSection = (i: number, updated: NoteSection) => {
    setEditSections(prev => prev.map((s, idx) => idx === i ? updated : s));
  };

  const handleDeleteSection = (i: number) => {
    setEditSections(prev => prev.filter((_, idx) => idx !== i));
  };

  const handleAddSection = () => {
    setEditSections(prev => [...prev, { heading: 'New Section', points: [''] }]);
  };

  const handleDelete = async () => {
    if (!note) return;
    setDeleting(true);
    try {
      await deleteNote(note.id);
      toast.success('Note deleted');
      navigate('/dashboard');
    } catch {
      toast.error('Failed to delete note');
      setDeleting(false);
    }
  };

  const sourceLabel: Record<string, string> = { pdf: 'PDF', youtube: 'YouTube', audio: 'Audio', lecture: 'Live Lecture', manual: 'Manual', text: 'Text' };
  const sourceColor: Record<string, string> = { pdf: '#EF4444', youtube: '#FF0000', audio: '#8B5CF6', lecture: '#3B82F6', manual: '#22C55E', text: '#FF6A00' };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0B0B0B' }}>
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF6A00' }} />
      </div>
    );
  }

  if (!note) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0B0B0B' }}>
        <div className="text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#FF6A00' }} />
          <h2 className="text-xl font-bold text-white mb-2">Note not found</h2>
          <p className="mb-6" style={{ color: '#B3B3B3' }}>This note may have been deleted.</p>
          <button onClick={() => navigate('/dashboard')} className="btn-orange flex items-center gap-2 mx-auto">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const displaySections = editing ? editSections : note.content.sections;

  return (
    <div className="min-h-screen" style={{ background: '#0B0B0B' }}>
      <header
        className="sticky top-0 z-30 px-4 md:px-8 py-4 flex items-center justify-between gap-3"
        style={{ background: 'rgba(11,11,11,0.95)', backdropFilter: 'blur(12px)', borderBottom: '1px solid #2A2A2A' }}
      >
        <div className="flex items-center gap-4 min-w-0">
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-sm flex-shrink-0" style={{ color: '#B3B3B3' }}>
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>
          <div className="min-w-0">
            {editing ? (
              <input
                value={editTitle}
                onChange={e => setEditTitle(e.target.value)}
                className="text-base font-bold text-white bg-transparent outline-none border-b w-full"
                style={{ borderBottomColor: '#FF6A00' }}
                placeholder="Note title..."
              />
            ) : (
              <h1 className="text-base font-bold text-white truncate">{note.title}</h1>
            )}
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: `${sourceColor[note.source] || '#FF6A00'}20`, color: sourceColor[note.source] || '#FF6A00' }}>
                {sourceLabel[note.source] || note.source}
              </span>
              {note.subject && <span className="text-xs" style={{ color: '#666' }}>{note.subject}</span>}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          {editing ? (
            <>
              <button
                onClick={cancelEdit}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium"
                style={{ background: '#2A2A2A', color: '#B3B3B3' }}
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline">Cancel</span>
              </button>
              <button
                onClick={handleSaveEdit}
                disabled={saving}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)', color: '#fff' }}
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                <span className="hidden sm:inline">Save Changes</span>
              </button>
            </>
          ) : (
            <>
              {note.flashcards && note.flashcards.length > 0 && (
                <button onClick={() => setShowFlashcards(true)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: 'rgba(139,92,246,0.1)', color: '#8B5CF6', border: '1px solid rgba(139,92,246,0.2)' }}>
                  <Brain className="w-4 h-4" />
                  <span className="hidden sm:inline">Flashcards</span>
                  <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: 'rgba(139,92,246,0.2)' }}>{note.flashcards.length}</span>
                </button>
              )}
              {note.quizQuestions && note.quizQuestions.length > 0 && (
                <button onClick={() => setShowQuiz(true)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: 'rgba(59,130,246,0.1)', color: '#3B82F6', border: '1px solid rgba(59,130,246,0.2)' }}>
                  <Sparkles className="w-4 h-4" />
                  <span className="hidden sm:inline">Quiz</span>
                  <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: 'rgba(59,130,246,0.2)' }}>{note.quizQuestions.length}</span>
                </button>
              )}
              <button
                onClick={enterEditMode}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium"
                style={{ background: 'rgba(255,106,0,0.1)', color: '#FF6A00', border: '1px solid rgba(255,106,0,0.2)' }}
              >
                <Edit3 className="w-4 h-4" />
                <span className="hidden sm:inline">Edit</span>
              </button>
              <button onClick={() => navigate('/chat')} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }}>
                <MessageSquare className="w-4 h-4" />
                <span className="hidden sm:inline">Ask AI</span>
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors disabled:opacity-50"
                style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}
                title="Delete note"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              </button>
            </>
          )}
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 flex gap-8">
        {/* Table of contents */}
        {!editing && (
          <aside className="hidden lg:block w-56 flex-shrink-0">
            <div className="sticky top-24 space-y-1">
              <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: '#666' }}>Contents</p>
              {note.content.sections.map((section, i) => (
                <button
                  key={i}
                  onClick={() => { setActiveSection(i); document.getElementById(`section-${i}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}
                  className="w-full text-left px-3 py-2 rounded-lg text-xs transition-all flex items-center gap-2"
                  style={{ background: activeSection === i ? 'rgba(255,106,0,0.1)' : 'transparent', color: activeSection === i ? '#FF6A00' : '#666' }}
                >
                  <ChevronRight className="w-3 h-3 flex-shrink-0" />
                  <span className="truncate">{section.heading}</span>
                </button>
              ))}
            </div>
          </aside>
        )}

        <main className="flex-1 min-w-0">
          {/* Edit mode banner */}
          {editing && (
            <div className="mb-6 flex items-center gap-3 px-4 py-3 rounded-xl" style={{ background: 'rgba(255,106,0,0.07)', border: '1px solid rgba(255,106,0,0.2)' }}>
              <Edit3 className="w-4 h-4 flex-shrink-0" style={{ color: '#FF6A00' }} />
              <p className="text-sm font-medium" style={{ color: '#FF6A00' }}>Edit mode — changes are saved when you click "Save Changes"</p>
            </div>
          )}

          {/* Meta */}
          {!editing && (
            <div className="flex flex-wrap items-center gap-4 mb-6 text-xs" style={{ color: '#666' }}>
              <div className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{new Date(note.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
              <div className="flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" />{note.content.sections.length} sections</div>
              {note.flashcards && note.flashcards.length > 0 && <div className="flex items-center gap-1.5"><Brain className="w-3.5 h-3.5" />{note.flashcards.length} flashcards</div>}
              {note.quizQuestions && note.quizQuestions.length > 0 && <div className="flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5" />{note.quizQuestions.length} quiz questions</div>}
            </div>
          )}

          {/* Summary */}
          {editing ? (
            <div className="mb-6">
              <label className="block text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#FF6A00' }}>📌 Summary</label>
              <textarea
                value={editSummary}
                onChange={e => setEditSummary(e.target.value)}
                rows={3}
                className="w-full px-4 py-3 rounded-xl text-sm leading-relaxed resize-none outline-none"
                style={{ background: 'rgba(255,106,0,0.05)', border: '1px solid rgba(255,106,0,0.2)', color: '#E0E0E0' }}
                placeholder="Brief overview of this note..."
              />
            </div>
          ) : note.summary ? (
            <div className="rounded-2xl p-5 mb-8" style={{ background: 'rgba(255,106,0,0.06)', border: '1px solid rgba(255,106,0,0.15)' }}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4" style={{ color: '#FF6A00' }} />
                <p className="text-sm font-semibold" style={{ color: '#FF6A00' }}>AI Summary</p>
              </div>
              <p className="text-sm leading-relaxed" style={{ color: '#E0E0E0' }}>{note.summary}</p>
            </div>
          ) : null}

          {/* Sections */}
          {editing ? (
            <div>
              {editSections.map((section, i) => (
                <EditableSection
                  key={i}
                  section={section}
                  index={i}
                  onUpdate={handleUpdateSection}
                  onDelete={handleDeleteSection}
                />
              ))}
              <button
                onClick={handleAddSection}
                className="w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 mt-2 transition-all"
                style={{ border: '2px dashed #2A2A2A', color: '#FF6A00', background: 'transparent' }}
              >
                <Plus className="w-4 h-4" />
                Add Section
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {note.content.sections.map((section, i) => (
                <section key={i} id={`section-${i}`} className="scroll-mt-24" onMouseEnter={() => setActiveSection(i)}>
                  <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0" style={{ background: 'rgba(255,106,0,0.15)', color: '#FF6A00' }}>
                      {i + 1}
                    </span>
                    {section.heading}
                  </h2>
                  <ul className="space-y-3 ml-2">
                    {section.points.map((point, j) => (
                      <li key={j} className="flex items-start gap-3">
                        <span className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0" style={{ background: '#FF6A00' }} />
                        <span className="text-sm leading-relaxed" style={{ color: '#D0D0D0' }}>{point}</span>
                      </li>
                    ))}
                  </ul>

                  {section.table && (
                    <div className="mt-4 overflow-x-auto rounded-xl" style={{ border: '1px solid #2A2A2A' }}>
                      <table className="w-full text-sm">
                        <thead>
                          <tr style={{ background: '#1A1A1A' }}>
                            {section.table.headers.map((h, k) => <th key={k} className="px-4 py-3 text-left font-semibold text-white">{h}</th>)}
                          </tr>
                        </thead>
                        <tbody>
                          {section.table.rows.map((row, k) => (
                            <tr key={k} style={{ borderTop: '1px solid #2A2A2A' }}>
                              {row.map((cell, l) => <td key={l} className="px-4 py-3" style={{ color: '#B3B3B3' }}>{cell}</td>)}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </section>
              ))}
            </div>
          )}

          {/* Action cards (view mode only) */}
          {!editing && (
            <>
              <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4">
                {note.flashcards && note.flashcards.length > 0 && (
                  <button onClick={() => setShowFlashcards(true)} className="card-dark p-5 text-left group">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: 'rgba(139,92,246,0.1)' }}>
                      <Brain className="w-5 h-5" style={{ color: '#8B5CF6' }} />
                    </div>
                    <p className="font-semibold text-white text-sm mb-1">Study Flashcards</p>
                    <p className="text-xs" style={{ color: '#666' }}>{note.flashcards.length} cards ready</p>
                  </button>
                )}
                {note.quizQuestions && note.quizQuestions.length > 0 && (
                  <button onClick={() => setShowQuiz(true)} className="card-dark p-5 text-left group">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: 'rgba(59,130,246,0.1)' }}>
                      <Sparkles className="w-5 h-5" style={{ color: '#3B82F6' }} />
                    </div>
                    <p className="font-semibold text-white text-sm mb-1">Take Quiz</p>
                    <p className="text-xs" style={{ color: '#666' }}>{note.quizQuestions.length} questions</p>
                  </button>
                )}
                <button onClick={() => navigate('/chat')} className="card-dark p-5 text-left group">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: 'rgba(255,106,0,0.1)' }}>
                    <MessageSquare className="w-5 h-5" style={{ color: '#FF6A00' }} />
                  </div>
                  <p className="font-semibold text-white text-sm mb-1">Chat with AI</p>
                  <p className="text-xs" style={{ color: '#666' }}>Ask questions about this note</p>
                </button>
              </div>

              {note.tags && note.tags.length > 0 && (
                <div className="mt-8 flex items-center gap-2 flex-wrap">
                  <Tag className="w-3.5 h-3.5" style={{ color: '#666' }} />
                  {note.tags.map(tag => (
                    <span key={tag} className="text-xs px-2 py-1 rounded-lg" style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }}>{tag}</span>
                  ))}
                </div>
              )}
            </>
          )}
        </main>
      </div>

      {showFlashcards && note.flashcards && note.flashcards.length > 0 && (
        <FlashcardModal flashcards={note.flashcards} onClose={() => setShowFlashcards(false)} />
      )}
      {showQuiz && note.quizQuestions && note.quizQuestions.length > 0 && (
        <QuizModal questions={note.quizQuestions} onClose={() => setShowQuiz(false)} />
      )}
    </div>
  );
}
