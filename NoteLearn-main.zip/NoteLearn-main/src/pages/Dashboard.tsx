import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Zap, Mic, Plus, BookOpen, FileText, Clock, Search,
  GraduationCap, Sparkles, ArrowRight, FolderOpen, ChevronRight, Brain, MessageSquare,
  Trash2, ChevronDown, MoveRight, X
} from 'lucide-react';
import Sidebar from '@/components/layout/Sidebar';
import NoteGeneratorPanel from '@/components/features/NoteGeneratorPanel';
import LiveCapturePanel from '@/components/features/LiveCapturePanel';
import AddSubjectModal from '@/components/features/AddSubjectModal';
import { useAuth, getSubjects, type Subject } from '@/hooks/useAuth';
import { getNotes, deleteNote, moveNote, decrementSubjectNoteCount, incrementSubjectNoteCount } from '@/lib/noteStorage';
import type { Note } from '@/types';
import { toast } from 'sonner';

type Tab = 'home' | 'generate' | 'record';

const QUICK_ACTIONS = [
  { icon: Zap, label: 'Generate Notes', desc: 'Upload PDF, paste text, or URL', tab: 'generate' as Tab, color: '#FF6A00' },
  { icon: Mic, label: 'Record Lecture', desc: 'Capture live audio with AI', tab: 'record' as Tab, color: '#8B5CF6' },
  { icon: MessageSquare, label: 'AI Chat', desc: 'Chat with your notes', tab: null, color: '#3B82F6', path: '/chat' },
];

const sourceLabel: Record<string, string> = { pdf: 'PDF', youtube: 'YouTube', audio: 'Audio', lecture: 'Lecture', manual: 'Manual', text: 'Text' };
const sourceColor: Record<string, string> = { pdf: '#EF4444', youtube: '#FF0000', audio: '#8B5CF6', lecture: '#3B82F6', manual: '#22C55E', text: '#FF6A00' };

// MoveNoteModal
function MoveNoteModal({ note, subjects, onMove, onClose }: { note: Note; subjects: Subject[]; onMove: (subjectId: string, subjectName: string) => void; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-sm animate-slide-up" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderRadius: '20px' }}>
        <div className="flex items-center justify-between px-6 py-5" style={{ borderBottom: '1px solid #2A2A2A' }}>
          <h2 className="text-base font-bold text-white">Move Note</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 space-y-2 max-h-72 overflow-y-auto">
          <p className="text-xs mb-3" style={{ color: '#666' }}>Move "{note.title}" to:</p>
          <button
            onClick={() => onMove('', 'General')}
            className="w-full text-left px-4 py-3 rounded-xl text-sm transition-all"
            style={{ background: !note.subjectId ? 'rgba(255,106,0,0.1)' : '#121212', color: !note.subjectId ? '#FF6A00' : '#B3B3B3', border: '1px solid #2A2A2A' }}
          >
            📂 No Subject (General)
          </button>
          {subjects.map(s => (
            <button
              key={s.id}
              onClick={() => onMove(s.id, s.name)}
              className="w-full text-left px-4 py-3 rounded-xl text-sm transition-all"
              style={{ background: note.subjectId === s.id ? 'rgba(255,106,0,0.1)' : '#121212', color: note.subjectId === s.id ? '#FF6A00' : '#B3B3B3', border: '1px solid #2A2A2A' }}
            >
              {s.icon} {s.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// SubjectNotesModal
function SubjectNotesModal({ subject, notes, subjects, onClose, onDeleteNote, onMoveNote, onNoteClick }: {
  subject: Subject; notes: Note[]; subjects: Subject[];
  onClose: () => void;
  onDeleteNote: (note: Note) => void;
  onMoveNote: (note: Note) => void;
  onNoteClick: (note: Note) => void;
}) {
  const subjectNotes = notes.filter(n => n.subjectId === subject.id);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-lg animate-slide-up" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderRadius: '20px', maxHeight: '80vh', display: 'flex', flexDirection: 'column' }}>
        <div className="flex items-center justify-between px-6 py-5 flex-shrink-0" style={{ borderBottom: '1px solid #2A2A2A' }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: `${subject.color}15` }}>
              {subject.icon}
            </div>
            <div>
              <h2 className="text-base font-bold text-white">{subject.name}</h2>
              <p className="text-xs" style={{ color: '#666' }}>{subjectNotes.length} note{subjectNotes.length !== 1 ? 's' : ''}</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {subjectNotes.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-10 h-10 mx-auto mb-3" style={{ color: '#2A2A2A' }} />
              <p className="font-semibold text-white mb-1">No notes yet</p>
              <p className="text-sm" style={{ color: '#666' }}>Generate your first note for this subject</p>
            </div>
          ) : (
            <div className="space-y-2">
              {subjectNotes.map(note => (
                <div
                  key={note.id}
                  className="flex items-center gap-3 p-3 rounded-xl cursor-pointer group transition-all"
                  style={{ background: '#121212', border: '1px solid #2A2A2A' }}
                >
                  <div
                    className="flex-1 min-w-0"
                    onClick={() => onNoteClick(note)}
                  >
                    <p className="font-medium text-sm text-white truncate">{note.title}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: `${sourceColor[note.source]}15`, color: sourceColor[note.source] }}>
                        {sourceLabel[note.source]}
                      </span>
                      <span className="text-xs flex items-center gap-1" style={{ color: '#666' }}>
                        <Clock className="w-3 h-3" />
                        {new Date(note.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onMoveNote(note)}
                      className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
                      style={{ color: '#666' }}
                      title="Move note"
                    >
                      <MoveRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteNote(note)}
                      className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
                      style={{ color: '#666' }}
                      title="Delete note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const [tab, setTab] = useState<Tab>(() => {
    const t = searchParams.get('tab');
    if (t === 'generate' || t === 'record') return t;
    return 'home';
  });
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [search, setSearch] = useState('');
  const [showAddSubject, setShowAddSubject] = useState(false);
  const [sidebarKey, setSidebarKey] = useState(0);
  const [showAllNotes, setShowAllNotes] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [noteToDelete, setNoteToDelete] = useState<Note | null>(null);
  const [noteToMove, setNoteToMove] = useState<Note | null>(null);

  const refreshAll = useCallback(async () => {
    if (!user) return;
    try {
      const [s, n] = await Promise.all([getSubjects(user.id), getNotes(user.id)]);
      setSubjects(s);
      setNotes(n);
      setSidebarKey(k => k + 1);
    } catch (err) {
      console.error('Refresh error:', err);
    }
  }, [user]);

  useEffect(() => { refreshAll(); }, [refreshAll]);
  useEffect(() => { if (tab === 'home') refreshAll(); }, [tab, refreshAll]);

  const handleTabChange = (newTab: Tab) => {
    setTab(newTab);
    if (newTab === 'home') { setSearchParams({}); refreshAll(); }
    else setSearchParams({ tab: newTab });
  };

  const handleDeleteNote = async (note: Note) => {
    try {
      await deleteNote(note.id);
      if (note.subjectId) await decrementSubjectNoteCount(note.subjectId);
      toast.success('Note deleted');
      setNoteToDelete(null);
      await refreshAll();
    } catch (err) {
      toast.error('Failed to delete note');
    }
  };

  const handleMoveNote = async (newSubjectId: string, newSubjectName: string) => {
    if (!noteToMove) return;
    try {
      const oldSubjectId = noteToMove.subjectId;
      await moveNote(noteToMove.id, newSubjectId, newSubjectName);
      if (oldSubjectId) await decrementSubjectNoteCount(oldSubjectId);
      if (newSubjectId) await incrementSubjectNoteCount(newSubjectId);
      toast.success(`Moved to ${newSubjectName || 'General'}`);
      setNoteToMove(null);
      await refreshAll();
    } catch (err) {
      toast.error('Failed to move note');
    }
  };

  const filteredNotes = search.trim()
    ? notes.filter(n => n.title.toLowerCase().includes(search.toLowerCase()) || n.subject.toLowerCase().includes(search.toLowerCase()))
    : notes;

  const displayedNotes = showAllNotes ? filteredNotes : filteredNotes.slice(0, 6);
  const firstName = user?.name?.split(' ')[0] || 'there';
  const totalFlashcards = notes.reduce((sum, n) => sum + (n.flashcards?.length || 0), 0);

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#0B0B0B' }}>
      <div className="w-64 flex-shrink-0 hidden md:block">
        <Sidebar key={sidebarKey} onSubjectChange={refreshAll} />
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Top bar */}
        <header className="sticky top-0 z-30 px-6 py-4 flex items-center justify-between" style={{ background: 'rgba(13,13,13,0.95)', backdropFilter: 'blur(12px)', borderBottom: '1px solid #2A2A2A' }}>
          <div className="flex items-center gap-4">
            <div className="md:hidden flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)' }}>
                <GraduationCap className="w-4 h-4 text-white" />
              </div>
              <span className="text-base font-bold text-white">NoteLearn</span>
            </div>
            <div className="hidden md:flex items-center gap-1 rounded-xl p-1" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
              {([
                { id: 'home', label: 'Overview' },
                { id: 'generate', label: '⚡ Generate' },
                { id: 'record', label: '🎙 Record' },
              ] as { id: Tab; label: string }[]).map(t => (
                <button
                  key={t.id}
                  onClick={() => handleTabChange(t.id)}
                  className="px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-200"
                  style={{
                    background: tab === t.id ? 'linear-gradient(135deg, #FF6A00, #FF8C00)' : 'transparent',
                    color: tab === t.id ? '#FFFFFF' : '#666',
                  }}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {tab === 'home' && (
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search notes..." className="input-dark pl-9 pr-4 py-2 text-sm w-52" />
              </div>
            )}
            <button onClick={() => navigate('/chat')} className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: 'rgba(255,106,0,0.1)', color: '#FF6A00', border: '1px solid rgba(255,106,0,0.2)' }}>
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">AI Chat</span>
            </button>
            <button onClick={() => setShowAddSubject(true)} className="btn-orange text-sm px-4 py-2 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Subject</span>
            </button>
          </div>
        </header>

        <main className="p-6">
          {tab === 'generate' && <NoteGeneratorPanel />}
          {tab === 'record' && <LiveCapturePanel />}

          {tab === 'home' && (
            <div className="max-w-5xl mx-auto">
              {/* Welcome */}
              <div className="mb-8">
                <h1 className="text-2xl md:text-3xl font-black text-white mb-1">
                  Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'},{' '}
                  <span className="gradient-text">{firstName}</span> 👋
                </h1>
                <p className="text-sm" style={{ color: '#B3B3B3' }}>
                  {notes.length === 0 && subjects.length === 0
                    ? "Let's get your study space set up."
                    : `${notes.length} note${notes.length !== 1 ? 's' : ''} across ${subjects.length} subject${subjects.length !== 1 ? 's' : ''}.`}
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
                {[
                  { label: 'Notes', value: notes.length, icon: FileText, color: '#FF6A00' },
                  { label: 'Subjects', value: subjects.length, icon: FolderOpen, color: '#3B82F6' },
                  { label: 'Flashcards', value: totalFlashcards, icon: Brain, color: '#8B5CF6' },
                ].map(stat => (
                  <div key={stat.label} className="card-dark p-5">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3" style={{ background: `${stat.color}12` }}>
                      <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
                    </div>
                    <p className="text-2xl font-black text-white">{stat.value}</p>
                    <p className="text-xs mt-0.5" style={{ color: '#666' }}>{stat.label}</p>
                  </div>
                ))}
              </div>

              {/* Quick actions */}
              <div className="mb-8">
                <h2 className="text-sm font-semibold uppercase tracking-wider mb-4" style={{ color: '#666' }}>Quick Actions</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {QUICK_ACTIONS.map(action => (
                    <button
                      key={action.label}
                      onClick={() => {
                        if (action.path) navigate(action.path);
                        else if (action.tab) handleTabChange(action.tab);
                      }}
                      className="card-dark p-5 text-left group"
                    >
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110" style={{ background: `${action.color}12`, border: `1px solid ${action.color}20` }}>
                        <action.icon className="w-5 h-5" style={{ color: action.color }} />
                      </div>
                      <p className="font-semibold text-white text-sm mb-1">{action.label}</p>
                      <p className="text-xs" style={{ color: '#666' }}>{action.desc}</p>
                      <div className="flex items-center gap-1 mt-3" style={{ color: action.color }}>
                        <span className="text-xs font-medium">Get started</span>
                        <ArrowRight className="w-3 h-3" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Recent Notes */}
              {filteredNotes.length > 0 && (
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-sm font-semibold uppercase tracking-wider" style={{ color: '#666' }}>
                      {search ? `Search Results (${filteredNotes.length})` : 'Recent Notes'}
                    </h2>
                    {notes.length > 6 && (
                      <button
                        onClick={() => setShowAllNotes(!showAllNotes)}
                        className="flex items-center gap-1 text-xs font-medium"
                        style={{ color: '#FF6A00' }}
                      >
                        {showAllNotes ? 'Show less' : `Show all ${notes.length}`}
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAllNotes ? 'rotate-180' : ''}`} />
                      </button>
                    )}
                  </div>
                  <div className="space-y-2">
                    {displayedNotes.map(note => (
                      <div key={note.id} className="card-dark p-4 flex items-center gap-4 group">
                        <div
                          className="flex-1 min-w-0 cursor-pointer"
                          onClick={() => navigate(`/note/${note.id}`)}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${sourceColor[note.source] || '#FF6A00'}12` }}>
                              <FileText className="w-4 h-4" style={{ color: sourceColor[note.source] || '#FF6A00' }} />
                            </div>
                            <div className="min-w-0">
                              <p className="font-semibold text-white text-sm truncate">{note.title}</p>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: `${sourceColor[note.source] || '#FF6A00'}15`, color: sourceColor[note.source] || '#FF6A00' }}>
                                  {sourceLabel[note.source]}
                                </span>
                                {note.subject && <span className="text-xs" style={{ color: '#666' }}>{note.subject}</span>}
                                <span className="text-xs flex items-center gap-1" style={{ color: '#666' }}>
                                  <Clock className="w-3 h-3" />
                                  {new Date(note.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                          {note.flashcards && note.flashcards.length > 0 && (
                            <span className="text-xs px-2 py-1 rounded-full" style={{ background: 'rgba(139,92,246,0.1)', color: '#8B5CF6' }}>
                              {note.flashcards.length} cards
                            </span>
                          )}
                          <button
                            onClick={() => setNoteToMove(note)}
                            className="w-7 h-7 rounded-lg flex items-center justify-center"
                            style={{ color: '#666' }}
                            title="Move note"
                          >
                            <MoveRight className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setNoteToDelete(note)}
                            className="w-7 h-7 rounded-lg flex items-center justify-center"
                            style={{ color: '#666' }}
                            title="Delete note"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <ChevronRight
                            className="w-4 h-4 cursor-pointer"
                            style={{ color: '#FF6A00' }}
                            onClick={() => navigate(`/note/${note.id}`)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                  {!showAllNotes && filteredNotes.length > 6 && (
                    <button
                      onClick={() => setShowAllNotes(true)}
                      className="w-full mt-3 py-3 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2"
                      style={{ background: '#121212', color: '#B3B3B3', border: '1px solid #2A2A2A' }}
                    >
                      Show {filteredNotes.length - 6} more notes
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  )}
                </div>
              )}

              {/* Subjects */}
              {subjects.length === 0 ? (
                <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid #2A2A2A' }}>
                  <div className="p-8 text-center" style={{ background: 'linear-gradient(135deg, rgba(255,106,0,0.06), rgba(255,106,0,0.02))' }}>
                    <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5" style={{ background: 'rgba(255,106,0,0.1)', border: '1px solid rgba(255,106,0,0.2)' }}>
                      <GraduationCap className="w-8 h-8" style={{ color: '#FF6A00' }} />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Set up your study space</h3>
                    <p className="text-sm mb-6 max-w-sm mx-auto leading-relaxed" style={{ color: '#B3B3B3' }}>
                      Create subject folders to organize your notes, flashcards, and quizzes.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                      <button onClick={() => setShowAddSubject(true)} className="btn-orange flex items-center gap-2 justify-center">
                        <Plus className="w-4 h-4" />
                        Create First Subject
                      </button>
                      <button onClick={() => handleTabChange('generate')} className="flex items-center gap-2 justify-center px-5 py-3 rounded-xl font-semibold text-sm" style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }}>
                        <Sparkles className="w-4 h-4" />
                        Generate a Note
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3" style={{ borderTop: '1px solid #2A2A2A' }}>
                    {[
                      { step: '1', title: 'Add Subjects', desc: 'Create folders for each subject', icon: FolderOpen },
                      { step: '2', title: 'Generate Notes', desc: 'Upload PDFs, paste text, or record', icon: Zap },
                      { step: '3', title: 'Study & Practice', desc: 'Use flashcards, quizzes, and AI', icon: BookOpen },
                    ].map(s => (
                      <div key={s.step} className="p-5 flex items-start gap-3" style={{ background: '#121212', borderRight: '1px solid #2A2A2A' }}>
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5" style={{ background: 'rgba(255,106,0,0.15)', color: '#FF6A00' }}>
                          {s.step}
                        </div>
                        <div>
                          <p className="font-semibold text-sm text-white mb-1">{s.title}</p>
                          <p className="text-xs leading-relaxed" style={{ color: '#666' }}>{s.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-sm font-semibold uppercase tracking-wider" style={{ color: '#666' }}>Your Subjects</h2>
                    <button onClick={() => setShowAddSubject(true)} className="flex items-center gap-1.5 text-sm font-medium" style={{ color: '#FF6A00' }}>
                      <Plus className="w-3.5 h-3.5" />
                      Add Subject
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {subjects.map(subject => {
                      const subjectNotes = notes.filter(n => n.subjectId === subject.id);
                      return (
                        <div
                          key={subject.id}
                          className="card-dark p-5 cursor-pointer group"
                          onClick={() => setSelectedSubject(subject)}
                        >
                          <div className="flex items-center justify-between mb-4">
                            <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl" style={{ background: `${subject.color}12`, border: `1px solid ${subject.color}20` }}>
                              {subject.icon}
                            </div>
                            <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: subject.color }} />
                          </div>
                          <p className="font-bold text-white mb-1">{subject.name}</p>
                          <p className="text-xs" style={{ color: '#666' }}>{subjectNotes.length} note{subjectNotes.length !== 1 ? 's' : ''}</p>
                          <div className="mt-4 pt-4 flex items-center justify-between" style={{ borderTop: '1px solid #2A2A2A' }}>
                            <span className="text-xs px-2 py-1 rounded-full font-medium" style={{ background: `${subject.color}12`, color: subject.color }}>
                              View Notes
                            </span>
                            <button
                              onClick={e => { e.stopPropagation(); handleTabChange('generate'); }}
                              className="text-xs flex items-center gap-1 font-medium"
                              style={{ color: '#666' }}
                            >
                              <Zap className="w-3 h-3" />
                              Add Note
                            </button>
                          </div>
                        </div>
                      );
                    })}

                    <button
                      onClick={() => setShowAddSubject(true)}
                      className="rounded-2xl p-5 text-left transition-all duration-200 flex flex-col items-center justify-center min-h-[160px] group"
                      style={{ border: '2px dashed #2A2A2A' }}
                    >
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-all group-hover:bg-orange-500/20" style={{ background: '#1A1A1A' }}>
                        <Plus className="w-5 h-5" style={{ color: '#444' }} />
                      </div>
                      <span className="text-sm font-medium" style={{ color: '#444' }}>New Subject</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Modals */}
      {showAddSubject && (
        <AddSubjectModal onClose={() => setShowAddSubject(false)} onAdded={() => refreshAll()} />
      )}

      {selectedSubject && (
        <SubjectNotesModal
          subject={selectedSubject}
          notes={notes}
          subjects={subjects}
          onClose={() => setSelectedSubject(null)}
          onDeleteNote={note => { setNoteToDelete(note); setSelectedSubject(null); }}
          onMoveNote={note => { setNoteToMove(note); setSelectedSubject(null); }}
          onNoteClick={note => navigate(`/note/${note.id}`)}
        />
      )}

      {noteToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
          <div className="w-full max-w-sm animate-slide-up p-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderRadius: '20px' }}>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(239,68,68,0.1)' }}>
              <Trash2 className="w-6 h-6" style={{ color: '#EF4444' }} />
            </div>
            <h3 className="text-base font-bold text-white text-center mb-1">Delete Note</h3>
            <p className="text-sm text-center mb-6" style={{ color: '#B3B3B3' }}>
              Are you sure you want to delete <strong className="text-white">"{noteToDelete.title}"</strong>? This cannot be undone.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setNoteToDelete(null)} className="flex-1 py-3 rounded-xl text-sm font-medium" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
                Cancel
              </button>
              <button onClick={() => handleDeleteNote(noteToDelete)} className="flex-1 py-3 rounded-xl text-sm font-medium" style={{ background: 'rgba(239,68,68,0.15)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.3)' }}>
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {noteToMove && (
        <MoveNoteModal
          note={noteToMove}
          subjects={subjects}
          onMove={handleMoveNote}
          onClose={() => setNoteToMove(null)}
        />
      )}
    </div>
  );
}
