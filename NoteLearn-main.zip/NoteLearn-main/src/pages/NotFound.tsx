import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { GraduationCap, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0B0B0B' }}>
      <div className="text-center animate-fade-in">
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6" style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)' }}>
          <GraduationCap className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-8xl font-black mb-4 gradient-text">404</h1>
        <p className="text-xl font-semibold text-white mb-2">Page not found</p>
        <p className="mb-8" style={{ color: '#B3B3B3' }}>The page you're looking for doesn't exist or has been moved.</p>
        <button onClick={() => navigate('/')} className="btn-orange flex items-center gap-2 mx-auto">
          <ArrowLeft className="w-4 h-4" />
          Return to Home
        </button>
      </div>
    </div>
  );
};

export default NotFound;
