import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Camera, User, Mail, Lock, Eye, EyeOff,
  Save, Loader2, CheckCircle, BookOpen, Brain, FileText, Calendar,
  AlertCircle, LogOut, Trash2
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';
import { getNotes } from '@/lib/noteStorage';
import { getSubjects } from '@/hooks/useAuth';
import { toast } from 'sonner';
import logo from '@/assets/logo.png';

export default function Profile() {
  const navigate = useNavigate();
  const { user, signOut, updateAvatar, updateName } = useAuth();

  // Profile state
  const [name, setName] = useState(user?.name || '');
  const [savingName, setSavingName] = useState(false);
  const [nameSuccess, setNameSuccess] = useState(false);

  // Avatar
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  // Password
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  // Stats
  const [stats, setStats] = useState({ notes: 0, subjects: 0, flashcards: 0, joinDate: '' });
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    if (!user) return;
    setName(user.name);
    Promise.all([getNotes(user.id), getSubjects(user.id)]).then(([notes, subjects]) => {
      const totalFlashcards = notes.reduce((sum, n) => sum + (n.flashcards?.length || 0), 0);
      setStats({
        notes: notes.length,
        subjects: subjects.length,
        flashcards: totalFlashcards,
        joinDate: new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      });
      setLoadingStats(false);
    }).catch(() => setLoadingStats(false));
  }, [user]);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 3 * 1024 * 1024) { toast.error('Image too large — max 3MB'); return; }

    setUploadingAvatar(true);
    try {
      const ext = file.name.split('.').pop() || 'jpg';
      const path = `${user.id}/avatar.${ext}`;
      const { error: uploadError } = await supabase.storage.from('avatars').upload(path, file, { upsert: true, contentType: file.type });
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path);
      await updateAvatar(publicUrl + `?t=${Date.now()}`);
      toast.success('Profile picture updated!');
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSaveName = async () => {
    if (!name.trim() || name.trim() === user?.name) return;
    setSavingName(true);
    try {
      await updateName(name.trim());
      setNameSuccess(true);
      toast.success('Name updated!');
      setTimeout(() => setNameSuccess(false), 2000);
    } catch {
      toast.error('Failed to update name.');
    } finally {
      setSavingName(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    if (newPassword.length < 6) { setPasswordError('New password must be at least 6 characters.'); return; }
    if (newPassword !== confirmPassword) { setPasswordError('Passwords do not match.'); return; }

    setSavingPassword(true);
    try {
      // Re-authenticate first
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user!.email,
        password: currentPassword,
      });
      if (signInError) throw new Error('Current password is incorrect.');

      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;

      toast.success('Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: unknown) {
      setPasswordError(err instanceof Error ? err.message : 'Failed to change password.');
    } finally {
      setSavingPassword(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const avatarSrc = user?.avatar ||
    `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user?.name || 'U')}&backgroundColor=FF6A00&textColor=ffffff`;

  return (
    <div className="min-h-screen" style={{ background: '#0B0B0B' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-30 px-4 md:px-8 py-4 flex items-center justify-between"
        style={{ background: 'rgba(11,11,11,0.95)', backdropFilter: 'blur(12px)', borderBottom: '1px solid #2A2A2A' }}
      >
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-sm" style={{ color: '#B3B3B3' }}>
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>
          <div className="flex items-center gap-2.5">
            <img src={logo} alt="NoteLearn" className="w-7 h-7 rounded-lg object-cover" />
            <span className="font-bold text-white text-base">Profile Settings</span>
          </div>
        </div>
        <button
          onClick={handleSignOut}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-colors"
          style={{ background: 'rgba(239,68,68,0.08)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}
        >
          <LogOut className="w-4 h-4" />
          <span className="hidden sm:inline">Sign Out</span>
        </button>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">

        {/* Avatar Section */}
        <div className="rounded-2xl p-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
          <h2 className="text-base font-bold text-white mb-5">Profile Picture</h2>
          <div className="flex items-center gap-6">
            <div className="relative flex-shrink-0">
              <img
                src={avatarSrc}
                alt={user?.name}
                className="w-20 h-20 rounded-2xl object-cover"
                style={{ border: '2px solid #2A2A2A' }}
              />
              {uploadingAvatar && (
                <div className="absolute inset-0 rounded-2xl flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.6)' }}>
                  <Loader2 className="w-6 h-6 animate-spin text-white" />
                </div>
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-white mb-1">{user?.name}</p>
              <p className="text-xs mb-3" style={{ color: '#666' }}>{user?.email}</p>
              <label className="cursor-pointer">
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploadingAvatar} />
                <span
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer"
                  style={{ background: 'rgba(255,106,0,0.1)', color: '#FF6A00', border: '1px solid rgba(255,106,0,0.25)' }}
                >
                  <Camera className="w-4 h-4" />
                  {uploadingAvatar ? 'Uploading...' : 'Change Photo'}
                </span>
              </label>
              <p className="text-xs mt-2" style={{ color: '#555' }}>JPG, PNG or WebP — max 3MB</p>
            </div>
          </div>
        </div>

        {/* Account Stats */}
        <div className="rounded-2xl p-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
          <h2 className="text-base font-bold text-white mb-5">Account Stats</h2>
          {loadingStats ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#FF6A00' }} />
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { icon: FileText, label: 'Notes', value: stats.notes, color: '#FF6A00' },
                { icon: BookOpen, label: 'Subjects', value: stats.subjects, color: '#3B82F6' },
                { icon: Brain, label: 'Flashcards', value: stats.flashcards, color: '#8B5CF6' },
                { icon: Calendar, label: 'Joined', value: stats.joinDate, color: '#22C55E', isText: true },
              ].map(stat => (
                <div key={stat.label} className="rounded-xl p-4 text-center" style={{ background: '#121212', border: '1px solid #2A2A2A' }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2" style={{ background: `${stat.color}12` }}>
                    <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
                  </div>
                  <p className={`font-black text-white mb-0.5 ${(stat as { isText?: boolean }).isText ? 'text-xs' : 'text-xl'}`}>{stat.value}</p>
                  <p className="text-xs" style={{ color: '#555' }}>{stat.label}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Display Name */}
        <div className="rounded-2xl p-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
          <h2 className="text-base font-bold text-white mb-5">Display Name</h2>
          <div className="flex gap-3">
            <div className="relative flex-1">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSaveName()}
                placeholder="Your display name"
                className="input-dark w-full pl-10 pr-4 py-3 text-sm"
              />
            </div>
            <button
              onClick={handleSaveName}
              disabled={savingName || !name.trim() || name.trim() === user?.name}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
              style={{ background: nameSuccess ? 'rgba(34,197,94,0.15)' : 'linear-gradient(135deg, #FF6A00, #FF8C00)', color: nameSuccess ? '#22C55E' : '#fff' }}
            >
              {savingName ? <Loader2 className="w-4 h-4 animate-spin" /> : nameSuccess ? <CheckCircle className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {nameSuccess ? 'Saved!' : 'Save'}
            </button>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <Mail className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#666' }} />
            <span className="text-xs" style={{ color: '#666' }}>{user?.email} · Email cannot be changed</span>
          </div>
        </div>

        {/* Change Password */}
        <div className="rounded-2xl p-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
          <h2 className="text-base font-bold text-white mb-1">Change Password</h2>
          <p className="text-sm mb-5" style={{ color: '#666' }}>Enter your current password to set a new one.</p>

          {passwordError && (
            <div className="flex items-start gap-3 px-4 py-3 rounded-xl mb-4" style={{ background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.2)' }}>
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: '#EF4444' }} />
              <p className="text-sm" style={{ color: '#EF4444' }}>{passwordError}</p>
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#666' }}>Current Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                <input
                  type={showCurrent ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={e => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                  className="input-dark w-full pl-10 pr-12 py-3 text-sm"
                />
                <button type="button" onClick={() => setShowCurrent(!showCurrent)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: '#666' }}>
                  {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#666' }}>New Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                <input
                  type={showNew ? 'text' : 'password'}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="Min. 6 characters"
                  className="input-dark w-full pl-10 pr-12 py-3 text-sm"
                />
                <button type="button" onClick={() => setShowNew(!showNew)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: '#666' }}>
                  {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {newPassword.length > 0 && (
                <div className="flex gap-1 mt-2">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-1 flex-1 rounded-full transition-all" style={{
                      background: newPassword.length >= (i + 1) * 2 ? (newPassword.length >= 8 ? '#22C55E' : '#FF6A00') : '#2A2A2A'
                    }} />
                  ))}
                </div>
              )}
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: '#666' }}>Confirm New Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="input-dark w-full pl-10 pr-4 py-3 text-sm"
                />
                {confirmPassword && newPassword && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {confirmPassword === newPassword
                      ? <CheckCircle className="w-4 h-4" style={{ color: '#22C55E' }} />
                      : <AlertCircle className="w-4 h-4" style={{ color: '#EF4444' }} />
                    }
                  </div>
                )}
              </div>
            </div>
            <button
              type="submit"
              disabled={savingPassword || !currentPassword || !newPassword || !confirmPassword}
              className="w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)', color: '#fff' }}
            >
              {savingPassword ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              Update Password
            </button>
          </form>
        </div>

        {/* Danger Zone */}
        <div className="rounded-2xl p-6" style={{ background: '#1A1A1A', border: '1px solid rgba(239,68,68,0.15)' }}>
          <h2 className="text-base font-bold text-white mb-1">Account Actions</h2>
          <p className="text-sm mb-5" style={{ color: '#666' }}>Manage your session.</p>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold transition-all"
            style={{ background: 'rgba(239,68,68,0.08)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}
          >
            <LogOut className="w-4 h-4" />
            Sign Out of All Devices
          </button>
        </div>
      </div>
    </div>
  );
}
