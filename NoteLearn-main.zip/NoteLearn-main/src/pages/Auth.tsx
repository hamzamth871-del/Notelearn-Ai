import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Eye, EyeOff, ArrowRight, Zap, Brain, Layers, MessageSquare, BookOpen, Mail, KeyRound, User } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import heroBg from '@/assets/hero-bg.jpg';
import logo from '@/assets/logo.png';

const features = [
  { icon: Zap, text: 'Generate notes from PDFs & videos' },
  { icon: Brain, text: 'Auto-create flashcards & quizzes' },
  { icon: Layers, text: 'Spaced repetition to maximize retention' },
  { icon: MessageSquare, text: 'Chat with your AI study assistant' },
];

type SignUpStep = 'email' | 'otp' | 'password';

export default function Auth() {
  const navigate = useNavigate();
  const { sendOtp, verifyOtpAndSetPassword, signInWithPassword } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');

  // Sign in state
  const [siEmail, setSiEmail] = useState('');
  const [siPassword, setSiPassword] = useState('');
  const [siShowPw, setSiShowPw] = useState(false);
  const [siLoading, setSiLoading] = useState(false);
  const [siError, setSiError] = useState('');

  // Sign up state
  const [suStep, setSuStep] = useState<SignUpStep>('email');
  const [suEmail, setSuEmail] = useState('');
  const [suName, setSuName] = useState('');
  const [suOtp, setSuOtp] = useState('');
  const [suPassword, setSuPassword] = useState('');
  const [suShowPw, setSuShowPw] = useState(false);
  const [suLoading, setSuLoading] = useState(false);
  const [suError, setSuError] = useState('');

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setSiError('');
    if (!siEmail.trim() || !siPassword.trim()) {
      setSiError('Email and password are required.');
      return;
    }
    setSiLoading(true);
    try {
      await signInWithPassword(siEmail.trim(), siPassword);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err: unknown) {
      setSiError(err instanceof Error ? err.message : 'Sign in failed.');
      setSiLoading(false);
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuError('');
    if (!suEmail.trim()) { setSuError('Email is required.'); return; }
    if (!suName.trim()) { setSuError('Your name is required.'); return; }
    setSuLoading(true);
    try {
      await sendOtp(suEmail.trim());
      toast.success(`Verification code sent to ${suEmail}`);
      setSuStep('otp');
    } catch (err: unknown) {
      setSuError(err instanceof Error ? err.message : 'Failed to send OTP.');
    } finally {
      setSuLoading(false);
    }
  };

  const handleVerifyAndCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuError('');
    if (!suOtp.trim()) { setSuError('Please enter the verification code.'); return; }
    if (suPassword.length < 6) { setSuError('Password must be at least 6 characters.'); return; }
    setSuLoading(true);
    try {
      await verifyOtpAndSetPassword(suEmail.trim(), suOtp.trim(), suPassword, suName.trim());
      toast.success('Account created! Welcome to NoteLearn 🎓');
      navigate('/dashboard');
    } catch (err: unknown) {
      setSuError(err instanceof Error ? err.message : 'Verification failed.');
      setSuLoading(false);
    }
  };

  const switchMode = (m: 'signin' | 'signup') => {
    setMode(m);
    setSiError('');
    setSuError('');
    setSuStep('email');
  };

  return (
    <div className="min-h-screen flex" style={{ background: '#0B0B0B' }}>
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-between w-[52%] relative overflow-hidden p-12">
        <div className="absolute inset-0 z-0">
          <img src={heroBg} alt="" className="w-full h-full object-cover opacity-15" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(11,11,11,0.85) 0%, rgba(11,11,11,0.7) 100%)' }} />
        </div>
        <div className="absolute bottom-1/3 left-0 w-80 h-80 rounded-full pointer-events-none z-0" style={{ background: 'radial-gradient(ellipse, rgba(255,106,0,0.14) 0%, transparent 70%)' }} />

        <div className="relative z-10">
          <Link to="/" className="flex items-center gap-3">
            <img src={logo} alt="NoteLearn" className="w-10 h-10 rounded-xl object-cover" />
            <span className="text-xl font-bold text-white">NoteLearn</span>
          </Link>
        </div>

        <div className="relative z-10 flex-1 flex flex-col justify-center max-w-md">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 w-fit" style={{ background: 'rgba(255,106,0,0.1)', border: '1px solid rgba(255,106,0,0.2)' }}>
            <Zap className="w-3.5 h-3.5" style={{ color: '#FF6A00' }} />
            <span className="text-xs font-semibold" style={{ color: '#FF6A00' }}>AI-Powered Learning</span>
          </div>
          <h2 className="text-4xl font-black text-white mb-4 leading-tight">
            Study smarter,<br /><span className="gradient-text">not harder</span>
          </h2>
          <p className="text-base mb-10 leading-relaxed" style={{ color: '#B3B3B3' }}>
            Transform any material into structured notes, flashcards, and quizzes — instantly.
          </p>
          <div className="space-y-4">
            {features.map((f, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(255,106,0,0.1)', border: '1px solid rgba(255,106,0,0.2)' }}>
                  <f.icon className="w-4 h-4" style={{ color: '#FF6A00' }} />
                </div>
                <span className="text-sm" style={{ color: '#B3B3B3' }}>{f.text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 pt-6" style={{ borderTop: '1px solid #2A2A2A' }}>
            <BookOpen className="w-5 h-5" style={{ color: '#FF6A00' }} />
            <p className="text-sm" style={{ color: '#666' }}>Your notes are securely stored in the cloud</p>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12" style={{ background: '#0D0D0D' }}>
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <Link to="/" className="flex lg:hidden items-center gap-2 justify-center mb-8">
            <img src={logo} alt="NoteLearn" className="w-9 h-9 rounded-xl object-cover" />
            <span className="text-lg font-bold text-white">NoteLearn</span>
          </Link>

          {/* Mode tabs */}
          <div className="flex rounded-xl p-1 mb-8" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
            {(['signin', 'signup'] as const).map((m) => (
              <button
                key={m}
                onClick={() => switchMode(m)}
                className="flex-1 py-2.5 text-sm font-semibold rounded-lg transition-all duration-200"
                style={{
                  background: mode === m ? 'linear-gradient(135deg, #FF6A00, #FF8C00)' : 'transparent',
                  color: mode === m ? '#FFFFFF' : '#666',
                  boxShadow: mode === m ? '0 0 20px rgba(255,106,0,0.25)' : 'none',
                }}
              >
                {m === 'signup' ? 'Sign Up' : 'Sign In'}
              </button>
            ))}
          </div>

          {/* SIGN IN */}
          {mode === 'signin' && (
            <div>
              <div className="mb-6">
                <h1 className="text-2xl font-black text-white mb-1">Welcome back</h1>
                <p className="text-sm" style={{ color: '#666' }}>Sign in to continue studying.</p>
              </div>
              {siError && (
                <div className="mb-4 px-4 py-3 rounded-xl text-sm" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: '#EF4444' }}>
                  {siError}
                </div>
              )}
              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: '#B3B3B3' }}>Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                    <input
                      type="email"
                      value={siEmail}
                      onChange={e => setSiEmail(e.target.value)}
                      placeholder="your@email.com"
                      autoComplete="email"
                      className="input-dark w-full pl-10 pr-4 py-3 text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: '#B3B3B3' }}>Password</label>
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                    <input
                      type={siShowPw ? 'text' : 'password'}
                      value={siPassword}
                      onChange={e => setSiPassword(e.target.value)}
                      placeholder="Enter your password"
                      autoComplete="current-password"
                      className="input-dark w-full pl-10 pr-12 py-3 text-sm"
                    />
                    <button type="button" onClick={() => setSiShowPw(!siShowPw)} className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center" style={{ color: '#666' }}>
                      {siShowPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={siLoading}
                  className="btn-orange w-full py-3.5 text-sm flex items-center justify-center gap-2 mt-2 disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {siLoading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : (
                    <>Sign In <ArrowRight className="w-4 h-4" /></>
                  )}
                </button>
              </form>
              <p className="mt-6 text-center text-sm" style={{ color: '#666' }}>
                Don't have an account?{' '}
                <button onClick={() => switchMode('signup')} className="font-semibold" style={{ color: '#FF6A00' }}>Sign up free</button>
              </p>
            </div>
          )}

          {/* SIGN UP */}
          {mode === 'signup' && (
            <div>
              <div className="mb-6">
                <h1 className="text-2xl font-black text-white mb-1">
                  {suStep === 'email' ? 'Create your account' : suStep === 'otp' ? 'Verify your email' : 'Set your password'}
                </h1>
                <p className="text-sm" style={{ color: '#666' }}>
                  {suStep === 'email' ? "Start your learning journey — it's free." : suStep === 'otp' ? `Enter the 4-digit code sent to ${suEmail}` : 'Almost done! Choose a secure password.'}
                </p>
              </div>

              {/* Step indicator */}
              <div className="flex items-center gap-2 mb-6">
                {(['email', 'otp', 'password'] as SignUpStep[]).map((step, i) => (
                  <div key={step} className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{
                        background: suStep === step ? '#FF6A00' : (['email', 'otp', 'password'].indexOf(suStep) > i) ? 'rgba(255,106,0,0.3)' : '#2A2A2A',
                        color: suStep === step ? '#fff' : '#666',
                      }}
                    >
                      {i + 1}
                    </div>
                    {i < 2 && <div className="w-8 h-0.5 rounded" style={{ background: (['email', 'otp', 'password'].indexOf(suStep) > i) ? 'rgba(255,106,0,0.5)' : '#2A2A2A' }} />}
                  </div>
                ))}
              </div>

              {suError && (
                <div className="mb-4 px-4 py-3 rounded-xl text-sm" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: '#EF4444' }}>
                  {suError}
                </div>
              )}

              {suStep === 'email' && (
                <form onSubmit={handleSendOtp} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: '#B3B3B3' }}>Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                      <input type="text" value={suName} onChange={e => setSuName(e.target.value)} placeholder="Alex Johnson" className="input-dark w-full pl-10 pr-4 py-3 text-sm" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: '#B3B3B3' }}>Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                      <input type="email" value={suEmail} onChange={e => setSuEmail(e.target.value)} placeholder="your@email.com" autoComplete="email" className="input-dark w-full pl-10 pr-4 py-3 text-sm" />
                    </div>
                  </div>
                  <button type="submit" disabled={suLoading} className="btn-orange w-full py-3.5 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed">
                    {suLoading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Send Verification Code <ArrowRight className="w-4 h-4" /></>}
                  </button>
                </form>
              )}

              {suStep === 'otp' && (
                <form onSubmit={e => { e.preventDefault(); setSuStep('password'); }} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: '#B3B3B3' }}>Verification Code</label>
                    <input
                      type="text"
                      value={suOtp}
                      onChange={e => setSuOtp(e.target.value.replace(/\D/g, '').slice(0, 4))}
                      placeholder="0000"
                      maxLength={4}
                      className="input-dark w-full px-4 py-4 text-center text-2xl font-mono tracking-[0.5em]"
                    />
                    <p className="text-xs mt-2" style={{ color: '#666' }}>Check your email inbox (and spam folder)</p>
                  </div>
                  <button type="submit" disabled={suOtp.length < 4} className="btn-orange w-full py-3.5 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed">
                    Continue <ArrowRight className="w-4 h-4" />
                  </button>
                  <button type="button" onClick={() => { setSuStep('email'); setSuOtp(''); setSuError(''); }} className="w-full py-2 text-sm" style={{ color: '#666' }}>
                    ← Change email
                  </button>
                </form>
              )}

              {suStep === 'password' && (
                <form onSubmit={handleVerifyAndCreate} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: '#B3B3B3' }}>Create Password</label>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
                      <input
                        type={suShowPw ? 'text' : 'password'}
                        value={suPassword}
                        onChange={e => setSuPassword(e.target.value)}
                        placeholder="Minimum 6 characters"
                        autoComplete="new-password"
                        className="input-dark w-full pl-10 pr-12 py-3 text-sm"
                      />
                      <button type="button" onClick={() => setSuShowPw(!suShowPw)} className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center" style={{ color: '#666' }}>
                        {suShowPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <div className="flex gap-1 mt-2">
                      {[...Array(4)].map((_, i) => (
                        <div key={i} className="h-1 flex-1 rounded-full transition-all" style={{
                          background: suPassword.length >= (i + 1) * 2 ? (suPassword.length >= 8 ? '#22C55E' : '#FF6A00') : '#2A2A2A'
                        }} />
                      ))}
                    </div>
                  </div>
                  <button type="submit" disabled={suLoading || suPassword.length < 6} className="btn-orange w-full py-3.5 text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed">
                    {suLoading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Create Account <ArrowRight className="w-4 h-4" /></>}
                  </button>
                </form>
              )}

              <p className="mt-6 text-center text-sm" style={{ color: '#666' }}>
                Already have an account?{' '}
                <button onClick={() => switchMode('signin')} className="font-semibold" style={{ color: '#FF6A00' }}>Sign in</button>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
