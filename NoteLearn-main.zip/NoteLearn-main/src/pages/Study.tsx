import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Brain, CheckCircle, XCircle, Minus, RotateCcw,
  BookOpen, Sparkles, ChevronLeft, ChevronRight, Loader2,
  Trophy, Target, Zap, GraduationCap, Filter
} from 'lucide-react';
import { useAuth, getSubjects, type Subject } from '@/hooks/useAuth';
import { getNotes } from '@/lib/noteStorage';
import type { Flashcard, Note } from '@/types';
import { toast } from 'sonner';

interface ExtendedCard extends Flashcard {
  noteTitle: string;
  noteId: string;
  subject: string;
}

type Rating = 'easy' | 'medium' | 'hard';
type SessionState = 'setup' | 'studying' | 'results';

function getCardStyle(rating: Rating | undefined) {
  if (!rating) return { bg: 'rgba(255,106,0,0.06)', border: 'rgba(255,106,0,0.15)', color: '#FF6A00', label: 'New' };
  if (rating === 'easy') return { bg: 'rgba(34,197,94,0.06)', border: 'rgba(34,197,94,0.2)', color: '#22C55E', label: 'Easy' };
  if (rating === 'medium') return { bg: 'rgba(245,158,11,0.06)', border: 'rgba(245,158,11,0.2)', color: '#F59E0B', label: 'Good' };
  return { bg: 'rgba(239,68,68,0.06)', border: 'rgba(239,68,68,0.2)', color: '#EF4444', label: 'Hard' };
}

export default function Study() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [sessionState, setSessionState] = useState<SessionState>('setup');
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  // Setup options
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [cardLimit, setCardLimit] = useState<number>(20);

  // Session state
  const [deck, setDeck] = useState<ExtendedCard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [ratings, setRatings] = useState<Record<string, Rating>>({});
  const [sessionDuration, setSessionDuration] = useState(0);
  const [sessionTimer, setSessionTimer] = useState<number | null>(null);

  useEffect(() => {
    if (!user) return;
    Promise.all([getSubjects(user.id), getNotes(user.id)]).then(([s, n]) => {
      setSubjects(s);
      setNotes(n);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [user]);

  // Build all flashcards from notes
  const allCards: ExtendedCard[] = notes.flatMap(note =>
    (note.flashcards || []).map(fc => ({
      ...fc,
      noteTitle: note.title,
      noteId: note.id,
      subject: note.subject,
    }))
  );

  const filteredCards = selectedSubjectId === 'all'
    ? allCards
    : allCards.filter(c => {
        const noteObj = notes.find(n => n.id === c.noteId);
        return noteObj?.subjectId === selectedSubjectId;
      });

  const totalAvailable = filteredCards.length;

  const startSession = () => {
    if (filteredCards.length === 0) {
      toast.error('No flashcards available for the selected subject.');
      return;
    }
    // Shuffle and limit
    const shuffled = [...filteredCards].sort(() => Math.random() - 0.5).slice(0, cardLimit);
    setDeck(shuffled);
    setCurrentIndex(0);
    setFlipped(false);
    setRatings({});
    setSessionDuration(0);
    setSessionState('studying');

    const timer = window.setInterval(() => setSessionDuration(d => d + 1), 1000);
    setSessionTimer(timer);
  };

  const handleRate = (rating: Rating) => {
    const card = deck[currentIndex];
    const newRatings = { ...ratings, [card.id]: rating };
    setRatings(newRatings);

    if (currentIndex < deck.length - 1) {
      setCurrentIndex(i => i + 1);
      setFlipped(false);
    } else {
      // End session
      if (sessionTimer) clearInterval(sessionTimer);
      setSessionState('results');
    }
  };

  const handleRestart = () => {
    if (sessionTimer) clearInterval(sessionTimer);
    setSessionState('setup');
  };

  const handleStudyHardOnly = () => {
    const hardCards = deck.filter(c => ratings[c.id] === 'hard');
    if (hardCards.length === 0) { toast.success('No hard cards — perfect session!'); return; }
    setDeck(hardCards);
    setCurrentIndex(0);
    setFlipped(false);
    setRatings({});
    setSessionDuration(0);
    setSessionState('studying');
    const timer = window.setInterval(() => setSessionDuration(d => d + 1), 1000);
    setSessionTimer(timer);
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const card = deck[currentIndex];
  const progress = deck.length > 0 ? ((currentIndex) / deck.length) * 100 : 0;
  const easyCount = Object.values(ratings).filter(r => r === 'easy').length;
  const medCount = Object.values(ratings).filter(r => r === 'medium').length;
  const hardCount = Object.values(ratings).filter(r => r === 'hard').length;
  const accuracy = deck.length > 0 ? Math.round((easyCount / deck.length) * 100) : 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0B0B0B' }}>
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF6A00' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#0B0B0B' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-30 px-4 md:px-8 py-4 flex items-center justify-between"
        style={{ background: 'rgba(11,11,11,0.95)', backdropFilter: 'blur(12px)', borderBottom: '1px solid #2A2A2A' }}
      >
        <div className="flex items-center gap-4">
          <button onClick={() => { if (sessionTimer) clearInterval(sessionTimer); navigate('/dashboard'); }} className="flex items-center gap-2 text-sm" style={{ color: '#B3B3B3' }}>
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #8B5CF6, #7C3AED)' }}>
              <Brain className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">Study Mode</p>
              {sessionState === 'studying' && (
                <p className="text-xs" style={{ color: '#666' }}>{currentIndex + 1} / {deck.length} · {formatTime(sessionDuration)}</p>
              )}
            </div>
          </div>
        </div>

        {sessionState === 'studying' && (
          <button
            onClick={handleRestart}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium"
            style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }}
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden sm:inline">Exit Session</span>
          </button>
        )}
      </header>

      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">

        {/* SETUP */}
        {sessionState === 'setup' && (
          <div className="w-full max-w-lg animate-fade-in">
            <div className="text-center mb-8">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: 'linear-gradient(135deg, rgba(139,92,246,0.2), rgba(139,92,246,0.1))', border: '1px solid rgba(139,92,246,0.3)' }}>
                <Brain className="w-8 h-8" style={{ color: '#8B5CF6' }} />
              </div>
              <h1 className="text-2xl font-black text-white mb-2">Study Mode</h1>
              <p style={{ color: '#B3B3B3' }}>
                {allCards.length === 0
                  ? 'Generate some notes first to create flashcards.'
                  : `${allCards.length} flashcard${allCards.length !== 1 ? 's' : ''} available across ${notes.filter(n => (n.flashcards?.length || 0) > 0).length} note${notes.filter(n => (n.flashcards?.length || 0) > 0).length !== 1 ? 's' : ''}.`
                }
              </p>
            </div>

            {allCards.length === 0 ? (
              <div className="text-center">
                <div className="rounded-2xl p-8 mb-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
                  <GraduationCap className="w-10 h-10 mx-auto mb-4" style={{ color: '#444' }} />
                  <p className="font-semibold text-white mb-2">No flashcards yet</p>
                  <p className="text-sm mb-4" style={{ color: '#666' }}>Generate notes from PDFs, YouTube videos, or text to automatically create flashcards.</p>
                  <button onClick={() => navigate('/dashboard?tab=generate')} className="btn-orange">
                    Generate Notes
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl overflow-hidden" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
                {/* Subject filter */}
                <div className="p-5" style={{ borderBottom: '1px solid #2A2A2A' }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Filter className="w-4 h-4" style={{ color: '#FF6A00' }} />
                    <label className="text-sm font-semibold text-white">Subject Filter</label>
                  </div>
                  <select
                    value={selectedSubjectId}
                    onChange={e => setSelectedSubjectId(e.target.value)}
                    className="input-dark w-full px-4 py-2.5 text-sm"
                  >
                    <option value="all">All Subjects ({allCards.length} cards)</option>
                    {subjects.filter(s => {
                      const subjectCards = allCards.filter(c => notes.find(n => n.id === c.noteId)?.subjectId === s.id);
                      return subjectCards.length > 0;
                    }).map(s => {
                      const count = allCards.filter(c => notes.find(n => n.id === c.noteId)?.subjectId === s.id).length;
                      return <option key={s.id} value={s.id}>{s.icon} {s.name} ({count} cards)</option>;
                    })}
                  </select>
                </div>

                {/* Card count */}
                <div className="p-5" style={{ borderBottom: '1px solid #2A2A2A' }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Target className="w-4 h-4" style={{ color: '#FF6A00' }} />
                    <label className="text-sm font-semibold text-white">Cards per Session</label>
                    <span className="ml-auto text-sm font-bold" style={{ color: '#FF6A00' }}>{Math.min(cardLimit, totalAvailable)} cards</span>
                  </div>
                  <input
                    type="range"
                    min={5}
                    max={Math.max(5, totalAvailable)}
                    step={5}
                    value={Math.min(cardLimit, Math.max(5, totalAvailable))}
                    onChange={e => setCardLimit(Number(e.target.value))}
                    className="w-full accent-orange-500"
                  />
                  <div className="flex justify-between text-xs mt-1" style={{ color: '#555' }}>
                    <span>5</span>
                    <span>{Math.max(5, totalAvailable)}</span>
                  </div>
                </div>

                {/* Session stats preview */}
                <div className="p-5 grid grid-cols-3 gap-4">
                  {[
                    { label: 'Available', value: totalAvailable, color: '#FF6A00' },
                    { label: 'Will Study', value: Math.min(cardLimit, totalAvailable), color: '#8B5CF6' },
                    { label: 'Est. Time', value: `~${Math.ceil(Math.min(cardLimit, totalAvailable) * 0.5)} min`, color: '#3B82F6' },
                  ].map(s => (
                    <div key={s.label} className="text-center">
                      <p className="text-lg font-black" style={{ color: s.color }}>{s.value}</p>
                      <p className="text-xs" style={{ color: '#555' }}>{s.label}</p>
                    </div>
                  ))}
                </div>

                <div className="px-5 pb-5">
                  <button
                    onClick={startSession}
                    disabled={totalAvailable === 0}
                    className="w-full py-4 rounded-xl font-bold text-base flex items-center justify-center gap-3 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{ background: 'linear-gradient(135deg, #8B5CF6, #7C3AED)', color: '#fff', boxShadow: '0 0 30px rgba(139,92,246,0.3)' }}
                  >
                    <Zap className="w-5 h-5" />
                    Start Session
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STUDYING */}
        {sessionState === 'studying' && card && (
          <div className="w-full max-w-lg animate-fade-in">
            {/* Progress bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between text-xs mb-2" style={{ color: '#666' }}>
                <span>Card {currentIndex + 1} of {deck.length}</span>
                <span>{Math.round(progress)}% complete</span>
              </div>
              <div className="w-full h-2 rounded-full" style={{ background: '#1A1A1A' }}>
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #8B5CF6, #6D28D9)' }}
                />
              </div>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-xs flex items-center gap-1" style={{ color: '#22C55E' }}>
                  <CheckCircle className="w-3 h-3" /> {easyCount} easy
                </span>
                <span className="text-xs flex items-center gap-1" style={{ color: '#F59E0B' }}>
                  <Minus className="w-3 h-3" /> {medCount} ok
                </span>
                <span className="text-xs flex items-center gap-1" style={{ color: '#EF4444' }}>
                  <XCircle className="w-3 h-3" /> {hardCount} hard
                </span>
              </div>
            </div>

            {/* Source label */}
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs px-2 py-1 rounded-full" style={{ background: 'rgba(139,92,246,0.1)', color: '#8B5CF6' }}>
                {card.subject || card.noteTitle}
              </span>
              {!flipped && <span className="text-xs" style={{ color: '#555' }}>Click to reveal answer</span>}
            </div>

            {/* Flashcard */}
            <div
              onClick={() => setFlipped(f => !f)}
              className="relative cursor-pointer rounded-3xl p-8 min-h-[280px] flex flex-col items-center justify-center text-center transition-all duration-300 select-none mb-6"
              style={{
                background: flipped ? 'rgba(139,92,246,0.07)' : '#1A1A1A',
                border: `2px solid ${flipped ? 'rgba(139,92,246,0.35)' : '#2A2A2A'}`,
              }}
            >
              <div className="absolute top-4 left-4">
                <span
                  className="text-xs px-2.5 py-1 rounded-full font-bold"
                  style={{
                    background: flipped ? 'rgba(139,92,246,0.15)' : 'rgba(255,106,0,0.1)',
                    color: flipped ? '#8B5CF6' : '#FF6A00',
                  }}
                >
                  {flipped ? '💡 Answer' : '❓ Question'}
                </span>
              </div>

              <p
                className="text-lg font-semibold leading-relaxed mt-6"
                style={{ color: flipped ? '#FFFFFF' : '#C0C0C0' }}
              >
                {flipped ? card.back : card.front}
              </p>

              {!flipped && (
                <p className="text-xs mt-4 opacity-40" style={{ color: '#B3B3B3' }}>
                  Tap to flip
                </p>
              )}
            </div>

            {/* Nav + Rating */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => { if (currentIndex > 0) { setCurrentIndex(i => i - 1); setFlipped(false); } }}
                disabled={currentIndex === 0}
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 disabled:opacity-30"
                style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', color: '#B3B3B3' }}
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {flipped ? (
                <div className="flex items-center gap-2 flex-1 justify-center">
                  <button
                    onClick={() => handleRate('hard')}
                    className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all"
                    style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.25)' }}
                  >
                    <XCircle className="w-4 h-4" /> Hard
                  </button>
                  <button
                    onClick={() => handleRate('medium')}
                    className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all"
                    style={{ background: 'rgba(245,158,11,0.1)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.25)' }}
                  >
                    <Minus className="w-4 h-4" /> OK
                  </button>
                  <button
                    onClick={() => handleRate('easy')}
                    className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all"
                    style={{ background: 'rgba(34,197,94,0.1)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.25)' }}
                  >
                    <CheckCircle className="w-4 h-4" /> Easy
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setFlipped(true)}
                  className="flex-1 py-3 rounded-xl text-sm font-semibold transition-all"
                  style={{ background: 'rgba(139,92,246,0.1)', color: '#8B5CF6', border: '1px solid rgba(139,92,246,0.25)' }}
                >
                  Flip Card →
                </button>
              )}

              <button
                onClick={() => { if (currentIndex < deck.length - 1) { setCurrentIndex(i => i + 1); setFlipped(false); } }}
                disabled={currentIndex === deck.length - 1}
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 disabled:opacity-30"
                style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', color: '#B3B3B3' }}
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* RESULTS */}
        {sessionState === 'results' && (
          <div className="w-full max-w-lg animate-fade-in text-center">
            <div className="rounded-3xl p-8 mb-6" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
              <div className="text-5xl mb-4">
                {accuracy >= 80 ? '🏆' : accuracy >= 50 ? '🎯' : '📚'}
              </div>
              <h2 className="text-2xl font-black text-white mb-1">
                {accuracy >= 80 ? 'Excellent Work!' : accuracy >= 50 ? 'Good Progress!' : 'Keep Studying!'}
              </h2>
              <p className="mb-6" style={{ color: '#B3B3B3' }}>Session complete in {formatTime(sessionDuration)}</p>

              {/* Score ring */}
              <div className="flex items-center justify-center mb-8">
                <div className="relative">
                  <svg width="120" height="120" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="52" fill="none" stroke="#2A2A2A" strokeWidth="12" />
                    <circle
                      cx="60" cy="60" r="52" fill="none"
                      stroke={accuracy >= 80 ? '#22C55E' : accuracy >= 50 ? '#F59E0B' : '#EF4444'}
                      strokeWidth="12"
                      strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 52}`}
                      strokeDashoffset={`${2 * Math.PI * 52 * (1 - accuracy / 100)}`}
                      transform="rotate(-90 60 60)"
                      style={{ transition: 'stroke-dashoffset 1s ease' }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-black text-white">{accuracy}%</span>
                    <span className="text-xs" style={{ color: '#666' }}>mastery</span>
                  </div>
                </div>
              </div>

              {/* Breakdown */}
              <div className="grid grid-cols-3 gap-3 mb-6">
                <div className="rounded-xl p-3" style={{ background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.2)' }}>
                  <p className="text-xl font-black" style={{ color: '#22C55E' }}>{easyCount}</p>
                  <p className="text-xs" style={{ color: '#666' }}>Easy ✓</p>
                </div>
                <div className="rounded-xl p-3" style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)' }}>
                  <p className="text-xl font-black" style={{ color: '#F59E0B' }}>{medCount}</p>
                  <p className="text-xs" style={{ color: '#666' }}>Good ~</p>
                </div>
                <div className="rounded-xl p-3" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
                  <p className="text-xl font-black" style={{ color: '#EF4444' }}>{hardCount}</p>
                  <p className="text-xs" style={{ color: '#666' }}>Hard ✗</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-3">
                {hardCount > 0 && (
                  <button
                    onClick={handleStudyHardOnly}
                    className="w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all"
                    style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.25)' }}
                  >
                    <RotateCcw className="w-4 h-4" />
                    Study {hardCount} Hard Card{hardCount !== 1 ? 's' : ''} Again
                  </button>
                )}
                <button
                  onClick={handleRestart}
                  className="w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all"
                  style={{ background: 'linear-gradient(135deg, #8B5CF6, #7C3AED)', color: '#fff' }}
                >
                  <Brain className="w-4 h-4" />
                  New Session
                </button>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2"
                  style={{ background: '#2A2A2A', color: '#B3B3B3' }}
                >
                  <BookOpen className="w-4 h-4" />
                  Back to Dashboard
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
