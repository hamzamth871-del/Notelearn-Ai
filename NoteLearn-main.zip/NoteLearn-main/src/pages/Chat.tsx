import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Send, Bot, User, Sparkles, BookOpen, Brain, Lightbulb, RotateCcw, ChevronDown
} from 'lucide-react';
import type { ChatMessage } from '@/types';
import { supabase } from '@/lib/supabase';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { getNotes } from '@/lib/noteStorage';
import { useAuth } from '@/hooks/useAuth';
import type { Note } from '@/types';

const quickPrompts = [
  { icon: '🔬', label: 'Explain this topic simply' },
  { icon: '🧠', label: 'Quiz me on this material' },
  { icon: '📝', label: 'Summarize the key points' },
  { icon: '❓', label: 'What are the most important concepts?' },
  { icon: '💡', label: 'Give me study tips for this topic' },
];

const suggestions = [
  { icon: BookOpen, label: 'Summarize my notes', color: '#3B82F6' },
  { icon: Brain, label: 'Test my knowledge', color: '#8B5CF6' },
  { icon: Lightbulb, label: 'Explain a concept', color: '#22C55E' },
];

function buildNotesContext(note: Note | null): string {
  if (!note) return '';
  const lines: string[] = [`Title: ${note.title}`, `Subject: ${note.subject}`];
  if (note.summary) lines.push(`Summary: ${note.summary}`);
  for (const section of note.content.sections) {
    lines.push(`\n## ${section.heading}`);
    for (const point of section.points) lines.push(`- ${point}`);
  }
  return lines.join('\n');
}

export default function Chat() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNoteId, setSelectedNoteId] = useState<string>('');
  const [showNoteSelector, setShowNoteSelector] = useState(false);

  useEffect(() => {
    if (user) {
      getNotes(user.id).then(n => {
        setNotes(n);
        if (n.length > 0) setSelectedNoteId(n[0].id);
      }).catch(console.error);
    }
  }, [user]);

  const selectedNote = notes.find(n => n.id === selectedNoteId) || null;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      role: 'assistant',
      content: "Hi! I'm your AI study assistant. Select a note from the dropdown to chat about it, or ask me any study question! 🎓",
      timestamp: new Date().toISOString(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Update welcome message when note is selected
  useEffect(() => {
    if (selectedNote) {
      setMessages(prev => [{
        ...prev[0],
        content: `Hi! I've loaded your notes on **${selectedNote.title}** and I'm ready to help you learn. Ask me anything — I can explain concepts, quiz you, or summarize key points. 🎓`,
      }, ...prev.slice(1)]);
    }
  }, [selectedNote?.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleNoteSelect = (noteId: string) => {
    setSelectedNoteId(noteId);
    setShowNoteSelector(false);
    const note = notes.find(n => n.id === noteId);
    const msg: ChatMessage = {
      id: Date.now().toString(),
      role: 'assistant',
      content: note
        ? `Switched to **${note.title}**. I've loaded these notes. What would you like to know?`
        : "No note selected. Ask me any study question!",
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, msg]);
  };

  const handleSend = async (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText || isTyping) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: messageText, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    const history = [...messages, userMsg].slice(-10).map(m => ({ role: m.role, content: m.content }));
    const notesContext = buildNotesContext(selectedNote);

    const { data, error: fnError } = await supabase.functions.invoke('ai-chat', {
      body: { messages: history, notesContext },
    });

    let content = '';
    if (fnError) {
      let msg = fnError.message;
      if (fnError instanceof FunctionsHttpError) {
        try { msg = await fnError.context?.text() || msg; } catch { /* ignore */ }
      }
      content = `Sorry, I encountered an error: ${msg}. Please try again.`;
    } else {
      content = data?.content || "Sorry, I couldn't generate a response. Please try again.";
    }

    setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content, timestamp: new Date().toISOString() }]);
    setIsTyping(false);
  };

  const handleClear = () => {
    setMessages([{ id: Date.now().toString(), role: 'assistant', content: "Chat cleared! I'm ready to help you study.", timestamp: new Date().toISOString() }]);
  };

  const renderMessageContent = (content: string) => {
    return content.split('\n').map((line, li) => {
      const parts = line.split(/(\*\*[^*]+\*\*)/g);
      return (
        <span key={li}>
          {parts.map((part, i) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={i} className="font-semibold text-white">{part.slice(2, -2)}</strong>;
            }
            return <span key={i}>{part}</span>;
          })}
          {li < content.split('\n').length - 1 && <br />}
        </span>
      );
    });
  };

  return (
    <div className="flex flex-col h-screen" style={{ background: '#0B0B0B' }}>
      <header className="flex items-center justify-between px-4 md:px-6 py-4 flex-shrink-0" style={{ borderBottom: '1px solid #2A2A2A', background: '#0B0B0B' }}>
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-sm" style={{ color: '#B3B3B3' }}>
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)' }}>
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">AI Study Assistant</p>
              <p className="text-xs" style={{ color: '#22C55E' }}>● Online</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setShowNoteSelector(!showNoteSelector)}
              className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl transition-colors"
              style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}
            >
              <BookOpen className="w-3.5 h-3.5" style={{ color: '#FF6A00' }} />
              <span className="text-xs truncate max-w-[140px]" style={{ color: '#B3B3B3' }}>
                {selectedNote ? selectedNote.title : 'Select a note'}
              </span>
              <ChevronDown className="w-3 h-3" style={{ color: '#666' }} />
            </button>

            {showNoteSelector && (
              <div className="absolute right-0 top-full mt-2 w-64 rounded-xl overflow-hidden z-50" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
                <div className="p-2">
                  <button onClick={() => handleNoteSelect('')} className="w-full text-left px-3 py-2 rounded-lg text-sm" style={{ color: '#666' }}>
                    No note (general chat)
                  </button>
                  {notes.length === 0 ? (
                    <p className="px-3 py-2 text-xs" style={{ color: '#666' }}>No notes yet. Generate some first!</p>
                  ) : (
                    notes.map(note => (
                      <button
                        key={note.id}
                        onClick={() => handleNoteSelect(note.id)}
                        className="w-full text-left px-3 py-2 rounded-lg text-sm transition-all"
                        style={{ background: selectedNoteId === note.id ? 'rgba(255,106,0,0.1)' : 'transparent', color: selectedNoteId === note.id ? '#FF6A00' : '#B3B3B3' }}
                      >
                        <p className="font-medium truncate">{note.title}</p>
                        <p className="text-xs" style={{ color: '#666' }}>{note.subject}</p>
                      </button>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          <button onClick={handleClear} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }} title="Clear chat">
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 md:px-0" onClick={() => setShowNoteSelector(false)}>
        <div className="max-w-3xl mx-auto py-6 space-y-4">
          {messages.length === 1 && (
            <div className="flex flex-wrap gap-2 justify-center mb-4 animate-fade-in">
              {suggestions.map(s => (
                <button key={s.label} onClick={() => handleSend(s.label)} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium" style={{ background: `${s.color}12`, color: s.color, border: `1px solid ${s.color}25` }}>
                  <s.icon className="w-3.5 h-3.5" />
                  {s.label}
                </button>
              ))}
            </div>
          )}

          {messages.map(msg => (
            <div key={msg.id} className={`flex items-start gap-3 animate-slide-up ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: msg.role === 'assistant' ? 'linear-gradient(135deg, #FF6A00, #FF8C00)' : '#2A2A2A' }}>
                {msg.role === 'assistant' ? <Bot className="w-5 h-5 text-white" /> : <User className="w-5 h-5" style={{ color: '#B3B3B3' }} />}
              </div>
              <div
                className="max-w-[78%] px-4 py-3 rounded-2xl text-sm leading-relaxed"
                style={{
                  background: msg.role === 'assistant' ? '#1A1A1A' : 'rgba(255,106,0,0.12)',
                  border: `1px solid ${msg.role === 'assistant' ? '#2A2A2A' : 'rgba(255,106,0,0.25)'}`,
                  color: msg.role === 'assistant' ? '#E0E0E0' : '#FFFFFF',
                  borderBottomRightRadius: msg.role === 'user' ? '4px' : '16px',
                  borderBottomLeftRadius: msg.role === 'assistant' ? '4px' : '16px',
                }}
              >
                {renderMessageContent(msg.content)}
                <p className="text-xs mt-1.5 opacity-50">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-start gap-3 animate-fade-in">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)' }}>
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="px-4 py-3 rounded-2xl" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderBottomLeftRadius: '4px' }}>
                <div className="flex items-center gap-1">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="w-2 h-2 rounded-full" style={{ background: '#FF6A00', animation: 'typing 1.2s ease infinite', animationDelay: `${i * 0.2}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Quick prompts */}
      <div className="px-4 md:px-0 pb-2">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {quickPrompts.map(p => (
              <button
                key={p.label}
                onClick={() => handleSend(p.label)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap flex-shrink-0 transition-all"
                style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,106,0,0.3)'; (e.currentTarget as HTMLElement).style.color = '#FFFFFF'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = '#2A2A2A'; (e.currentTarget as HTMLElement).style.color = '#B3B3B3'; }}
              >
                <span>{p.icon}</span>
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input */}
      <div className="px-4 md:px-0 pb-4 flex-shrink-0">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-end gap-3 p-3 rounded-2xl" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
            <div className="flex-1">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                placeholder="Ask anything about your notes..."
                rows={1}
                className="w-full bg-transparent text-sm text-white placeholder-gray-600 outline-none resize-none leading-relaxed"
                style={{ maxHeight: '120px' }}
              />
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" style={{ color: '#FF6A00' }} />
                <span className="text-xs" style={{ color: '#666' }}>AI</span>
              </div>
              <button
                onClick={() => handleSend()}
                disabled={!input.trim() || isTyping}
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-all disabled:opacity-40"
                style={{ background: input.trim() && !isTyping ? 'linear-gradient(135deg, #FF6A00, #FF8C00)' : '#2A2A2A' }}
              >
                <Send className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
          <p className="text-center text-xs mt-2" style={{ color: '#444' }}>
            AI may make mistakes. Always verify important information.
          </p>
        </div>
      </div>
    </div>
  );
}
