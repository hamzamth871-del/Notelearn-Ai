import { useNavigate } from 'react-router-dom';
import { ArrowRight, Zap, Brain, Layers, MessageSquare, Upload, LayoutDashboard, Mic, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useEffect, useState } from 'react';
import heroBg from '@/assets/hero-bg.jpg';
import logo from '@/assets/logo.png';

const features = [
  {
    icon: Zap,
    title: 'Smart Note Generator',
    desc: 'Upload PDFs, YouTube links, or paste text. Get structured notes, bullet points, summaries, and tables instantly.',
    badge: 'AI-Powered',
  },
  {
    icon: Brain,
    title: 'Live Lecture Capture',
    desc: 'Record lectures in real-time. AI transcribes and highlights key points automatically as you listen.',
    badge: 'Real-Time',
  },
  {
    icon: Layers,
    title: 'Flashcards & Quizzes',
    desc: 'Auto-generate spaced repetition flashcards and multiple-choice quizzes with detailed explanations.',
    badge: 'Spaced Repetition',
  },
  {
    icon: MessageSquare,
    title: 'AI Study Chatbot',
    desc: 'Chat with your notes. Ask questions, get simple explanations, and test your knowledge in conversation.',
    badge: 'Interactive',
  },
];

const navLinks = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
  { icon: Zap, label: 'Note Generator', path: '/dashboard?tab=generate' },
  { icon: Mic, label: 'Live Capture', path: '/dashboard?tab=record' },
  { icon: MessageSquare, label: 'AI Chat', path: '/chat' },
];

export default function Index() {
  const navigate = useNavigate();
  const { user, loading, signOut } = useAuth();

  const goToApp = () => {
    if (user) navigate('/dashboard');
    else navigate('/auth');
  };

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <div className="min-h-screen" style={{ background: '#0B0B0B' }}>
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4" style={{ background: 'rgba(11,11,11,0.9)', backdropFilter: 'blur(16px)', borderBottom: '1px solid #1A1A1A' }}>
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
          <img src={logo} alt="NoteLearn" className="w-9 h-9 rounded-xl object-cover" />
          <span className="text-lg font-bold text-white">NoteLearn</span>
        </div>

        {/* Navigation links (logged-in users) */}
        {user && (
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((item) => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all"
                style={{ color: '#B3B3B3' }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.color = '#FFFFFF';
                  (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.05)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.color = '#B3B3B3';
                  (e.currentTarget as HTMLElement).style.background = 'transparent';
                }}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </div>
        )}

        {/* Right actions */}
        <div className="flex items-center gap-3">
          {user ? (
            <>
              <button
                onClick={goToApp}
                className="btn-orange text-sm px-4 py-2"
              >
                Open App
              </button>
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 text-sm px-4 py-2 rounded-xl font-medium transition-all"
                style={{ background: '#1A1A1A', color: '#B3B3B3', border: '1px solid #2A2A2A' }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.color = '#FFFFFF';
                  (e.currentTarget as HTMLElement).style.borderColor = '#FF6A00';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.color = '#B3B3B3';
                  (e.currentTarget as HTMLElement).style.borderColor = '#2A2A2A';
                }}
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </>
          ) : (
            <>
              <button
                onClick={goToApp}
                className="text-sm px-4 py-2 rounded-xl transition-colors font-medium"
                style={{ color: '#B3B3B3' }}
                onMouseEnter={e => (e.currentTarget.style.color = '#FFFFFF')}
                onMouseLeave={e => (e.currentTarget.style.color = '#B3B3B3')}
              >
                Sign in
              </button>
              <button onClick={goToApp} className="btn-orange text-sm px-4 py-2">
                Get Started Free
              </button>
            </>
          )}
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-4 pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={heroBg} alt="NoteLearn hero" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(11,11,11,0.3) 0%, rgba(11,11,11,0.8) 60%, #0B0B0B 100%)' }} />
        </div>
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full pointer-events-none" style={{ background: 'radial-gradient(ellipse, rgba(255,106,0,0.12) 0%, transparent 70%)' }} />

        <div className="relative z-10 max-w-4xl mx-auto animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{ background: 'rgba(255,106,0,0.1)', border: '1px solid rgba(255,106,0,0.25)' }}>
            <Zap className="w-3.5 h-3.5" style={{ color: '#FF6A00' }} />
            <span className="text-xs font-semibold" style={{ color: '#FF6A00' }}>AI-Powered Study Assistant</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight tracking-tight">
            <span className="text-white">Turn Anything Into</span>
            <br />
            <span className="gradient-text">Smart Notes</span>
          </h1>

          <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto leading-relaxed" style={{ color: '#B3B3B3' }}>
            Upload PDFs, YouTube videos, or record live lectures. NoteLearn's AI transforms any content into structured notes, flashcards, and quizzes — in seconds.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <button
              onClick={goToApp}
              className="btn-orange animate-pulse-glow flex items-center gap-2 px-8 py-4 text-base w-full sm:w-auto justify-center"
            >
              <Upload className="w-5 h-5" />
              Start Learning Free
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 py-20 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-black mb-4">
            <span className="text-white">Everything you need to</span>
            <br />
            <span className="gradient-text">study smarter</span>
          </h2>
          <p className="text-lg" style={{ color: '#B3B3B3' }}>Four powerful tools, one seamless experience</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feat, i) => (
            <div key={i} className="card-dark p-7 cursor-pointer group" onClick={goToApp}>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all group-hover:scale-110" style={{ background: 'rgba(255,106,0,0.12)', border: '1px solid rgba(255,106,0,0.2)' }}>
                  <feat.icon className="w-6 h-6" style={{ color: '#FF6A00' }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-white text-lg">{feat.title}</h3>
                    <span className="badge-orange">{feat.badge}</span>
                  </div>
                  <p className="leading-relaxed" style={{ color: '#B3B3B3' }}>{feat.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 py-20 text-center">
        <div className="max-w-2xl mx-auto rounded-3xl p-12 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, rgba(255,106,0,0.1), rgba(255,106,0,0.05))', border: '1px solid rgba(255,106,0,0.2)' }}>
          <div className="absolute inset-0 opacity-50" style={{ background: 'radial-gradient(ellipse at center, rgba(255,106,0,0.1) 0%, transparent 70%)' }} />
          <div className="relative z-10">
            <h2 className="text-4xl font-black text-white mb-4">Ready to study smarter?</h2>
            <p className="text-lg mb-8" style={{ color: '#B3B3B3' }}>Join thousands of students who already use NoteLearn</p>
            <button onClick={goToApp} className="btn-orange animate-pulse-glow px-10 py-4 text-base">
              Start for Free
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 text-center" style={{ borderTop: '1px solid #1A1A1A' }}>
        <div className="flex items-center justify-center gap-2">
          <img src={logo} alt="NoteLearn" className="w-6 h-6 rounded-lg object-cover" />
          <span className="font-bold text-white">NoteLearn</span>
        </div>
      </footer>
    </div>
  );
}
