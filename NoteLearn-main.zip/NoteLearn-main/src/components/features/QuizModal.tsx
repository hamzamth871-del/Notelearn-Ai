import { useState } from 'react';
import { X, CheckCircle, XCircle, ArrowRight, RotateCcw } from 'lucide-react';
import type { QuizQuestion } from '@/types';

interface QuizModalProps {
  questions: QuizQuestion[];
  onClose: () => void;
}

export default function QuizModal({ questions, onClose }: QuizModalProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [shortAnswer, setShortAnswer] = useState('');
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const current = questions[currentIndex];
  const isCorrect = selectedAnswer === current.correctAnswer ||
    (current.type === 'short-answer' && shortAnswer.toLowerCase().includes(current.correctAnswer.toLowerCase().split(',')[0].toLowerCase().trim()));

  const handleAnswerSelect = (answer: string) => {
    if (showExplanation) return;
    setSelectedAnswer(answer);
  };

  const handleCheck = () => {
    setShowExplanation(true);
    if (isCorrect) setScore(prev => prev + 1);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShortAnswer('');
      setShowExplanation(false);
    } else {
      setFinished(true);
    }
  };

  const handleReset = () => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShortAnswer('');
    setShowExplanation(false);
    setScore(0);
    setFinished(false);
  };

  const getOptionStyle = (option: string) => {
    if (!showExplanation) {
      return selectedAnswer === option
        ? { background: 'rgba(255,106,0,0.15)', border: '1px solid rgba(255,106,0,0.5)', color: '#FFFFFF' }
        : { background: '#121212', border: '1px solid #2A2A2A', color: '#B3B3B3' };
    }
    if (option === current.correctAnswer) {
      return { background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.4)', color: '#22C55E' };
    }
    if (option === selectedAnswer && option !== current.correctAnswer) {
      return { background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.4)', color: '#EF4444' };
    }
    return { background: '#121212', border: '1px solid #2A2A2A', color: '#666' };
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-2xl animate-slide-up" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderRadius: '20px' }}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: '#2A2A2A' }}>
          <div>
            <h2 className="text-xl font-bold text-white">Quiz</h2>
            <p className="text-sm mt-0.5" style={{ color: '#B3B3B3' }}>
              {finished ? 'Completed' : `Question ${currentIndex + 1} of ${questions.length}`} • Score: {score}/{questions.length}
            </p>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {finished ? (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">{score === questions.length ? '🏆' : score >= questions.length / 2 ? '✅' : '📚'}</div>
              <h3 className="text-2xl font-bold text-white mb-2">
                {score === questions.length ? 'Perfect Score!' : score >= questions.length / 2 ? 'Good Job!' : 'Keep Studying!'}
              </h3>
              <p className="text-4xl font-black mb-1" style={{ color: '#FF6A00' }}>{score}/{questions.length}</p>
              <p className="mb-6" style={{ color: '#B3B3B3' }}>{Math.round((score / questions.length) * 100)}% accuracy</p>
              <div className="flex gap-3 justify-center">
                <button onClick={handleReset} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
                  <RotateCcw className="w-4 h-4" /> Retry
                </button>
                <button onClick={onClose} className="btn-orange">Done</button>
              </div>
            </div>
          ) : (
            <>
              {/* Progress */}
              <div className="w-full h-1 rounded-full mb-6" style={{ background: '#2A2A2A' }}>
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${((currentIndex + 1) / questions.length) * 100}%`, background: 'linear-gradient(90deg, #FF6A00, #FF8C00)' }}
                />
              </div>

              {/* Question */}
              <div className="mb-2">
                <span className="badge-orange text-xs">{current.type === 'multiple-choice' ? 'Multiple Choice' : 'Short Answer'}</span>
              </div>
              <h3 className="text-lg font-semibold text-white mb-4 leading-relaxed">{current.question}</h3>

              {/* Options */}
              {current.type === 'multiple-choice' ? (
                <div className="space-y-3 mb-4">
                  {current.options?.map((option) => (
                    <button
                      key={option}
                      onClick={() => handleAnswerSelect(option)}
                      className="w-full text-left p-4 rounded-xl transition-all duration-200 flex items-center justify-between"
                      style={getOptionStyle(option)}
                    >
                      <span className="font-medium">{option}</span>
                      {showExplanation && option === current.correctAnswer && <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />}
                      {showExplanation && option === selectedAnswer && option !== current.correctAnswer && <XCircle className="w-5 h-5 text-red-500 flex-shrink-0" />}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="mb-4">
                  <input
                    type="text"
                    value={shortAnswer}
                    onChange={(e) => setShortAnswer(e.target.value)}
                    disabled={showExplanation}
                    placeholder="Type your answer..."
                    className="input-dark w-full px-4 py-3"
                    onKeyDown={(e) => e.key === 'Enter' && !showExplanation && shortAnswer && handleCheck()}
                  />
                </div>
              )}

              {/* Explanation */}
              {showExplanation && (
                <div
                  className="p-4 rounded-xl mb-4 animate-fade-in"
                  style={{
                    background: isCorrect ? 'rgba(34,197,94,0.08)' : 'rgba(239,68,68,0.08)',
                    border: `1px solid ${isCorrect ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'}`,
                  }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    {isCorrect ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
                    <span className="font-semibold" style={{ color: isCorrect ? '#22C55E' : '#EF4444' }}>
                      {isCorrect ? 'Correct!' : `Incorrect — Answer: ${current.correctAnswer}`}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: '#B3B3B3' }}>{current.explanation}</p>
                </div>
              )}

              {/* Actions */}
              <div className="flex justify-end gap-3">
                {!showExplanation ? (
                  <button
                    onClick={handleCheck}
                    disabled={!selectedAnswer && !shortAnswer}
                    className="btn-orange disabled:opacity-40 disabled:cursor-not-allowed"
                    style={!selectedAnswer && !shortAnswer ? { boxShadow: 'none', transform: 'none' } : {}}
                  >
                    Check Answer
                  </button>
                ) : (
                  <button onClick={handleNext} className="btn-orange flex items-center gap-2">
                    {currentIndex < questions.length - 1 ? 'Next Question' : 'See Results'}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
