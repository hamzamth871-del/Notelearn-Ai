import { useState } from 'react';
import { X, ChevronLeft, ChevronRight, RotateCcw, CheckCircle, XCircle, Minus } from 'lucide-react';
import type { Flashcard } from '@/types';

interface FlashcardModalProps {
  flashcards: Flashcard[];
  onClose: () => void;
}

export default function FlashcardModal({ flashcards, onClose }: FlashcardModalProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [results, setResults] = useState<Record<string, 'easy' | 'medium' | 'hard'>>({});

  const current = flashcards[currentIndex];
  const progress = Object.keys(results).length;

  const handleFlip = () => setIsFlipped(!isFlipped);

  const handleRate = (difficulty: 'easy' | 'medium' | 'hard') => {
    setResults(prev => ({ ...prev, [current.id]: difficulty }));
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsFlipped(false);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setIsFlipped(false);
    }
  };

  const handleNext = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsFlipped(false);
    }
  };

  const handleReset = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setResults({});
  };

  const allDone = progress === flashcards.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-2xl animate-slide-up" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderRadius: '20px' }}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: '#2A2A2A' }}>
          <div>
            <h2 className="text-xl font-bold text-white">Flashcards</h2>
            <p className="text-sm mt-0.5" style={{ color: '#B3B3B3' }}>{currentIndex + 1} of {flashcards.length}</p>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="px-6 pt-4">
          <div className="w-full h-1.5 rounded-full" style={{ background: '#2A2A2A' }}>
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${((currentIndex + 1) / flashcards.length) * 100}%`, background: 'linear-gradient(90deg, #FF6A00, #FF8C00)' }}
            />
          </div>
        </div>

        {/* Card */}
        <div className="p-6">
          {allDone ? (
            <div className="text-center py-8">
              <div className="text-5xl mb-4">🎉</div>
              <h3 className="text-2xl font-bold text-white mb-2">Session Complete!</h3>
              <p className="mb-6" style={{ color: '#B3B3B3' }}>
                {Object.values(results).filter(r => r === 'easy').length} Easy •{' '}
                {Object.values(results).filter(r => r === 'medium').length} Medium •{' '}
                {Object.values(results).filter(r => r === 'hard').length} Hard
              </p>
              <button onClick={handleReset} className="btn-orange flex items-center gap-2 mx-auto">
                <RotateCcw className="w-4 h-4" />
                Review Again
              </button>
            </div>
          ) : (
            <>
              {/* Flashcard */}
              <div
                onClick={handleFlip}
                className="relative cursor-pointer rounded-2xl p-8 min-h-[200px] flex flex-col items-center justify-center text-center transition-all duration-300 select-none"
                style={{
                  background: isFlipped ? 'rgba(255,106,0,0.08)' : '#121212',
                  border: `1px solid ${isFlipped ? 'rgba(255,106,0,0.3)' : '#2A2A2A'}`,
                }}
              >
                <div className="absolute top-3 right-3">
                  <span className="badge-orange text-xs">{isFlipped ? 'Answer' : 'Question'}</span>
                </div>
                <p className="text-lg font-medium leading-relaxed" style={{ color: isFlipped ? '#FFFFFF' : '#B3B3B3' }}>
                  {isFlipped ? current.back : current.front}
                </p>
                {!isFlipped && (
                  <p className="text-xs mt-4" style={{ color: '#666' }}>Click to reveal answer</p>
                )}
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={handlePrev}
                  disabled={currentIndex === 0}
                  className="w-10 h-10 rounded-xl flex items-center justify-center transition-colors disabled:opacity-30"
                  style={{ background: '#2A2A2A', color: '#B3B3B3' }}
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                {isFlipped ? (
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleRate('hard')}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all"
                      style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}
                    >
                      <XCircle className="w-4 h-4" /> Hard
                    </button>
                    <button
                      onClick={() => handleRate('medium')}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all"
                      style={{ background: 'rgba(245,158,11,0.1)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.2)' }}
                    >
                      <Minus className="w-4 h-4" /> OK
                    </button>
                    <button
                      onClick={() => handleRate('easy')}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all"
                      style={{ background: 'rgba(34,197,94,0.1)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.2)' }}
                    >
                      <CheckCircle className="w-4 h-4" /> Easy
                    </button>
                  </div>
                ) : (
                  <p className="text-sm" style={{ color: '#666' }}>Rate after flipping</p>
                )}

                <button
                  onClick={handleNext}
                  disabled={currentIndex === flashcards.length - 1}
                  className="w-10 h-10 rounded-xl flex items-center justify-center transition-colors disabled:opacity-30"
                  style={{ background: '#2A2A2A', color: '#B3B3B3' }}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
