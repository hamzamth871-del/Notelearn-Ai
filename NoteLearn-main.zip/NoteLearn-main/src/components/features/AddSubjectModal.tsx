import { useState } from 'react';
import { X, Plus } from 'lucide-react';
import { createSubject, type Subject } from '@/hooks/useAuth';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

const PRESET_ICONS = ['🧬', '📐', '💻', '📜', '⚛️', '🌍', '📚', '🎨', '🎵', '🏛️', '🔬', '💊', '⚖️', '🌱', '🧠', '🔢'];
const PRESET_COLORS = [
  '#FF6A00', '#3B82F6', '#8B5CF6', '#22C55E',
  '#EC4899', '#F59E0B', '#EF4444', '#06B6D4',
  '#6366F1', '#84CC16', '#F97316', '#A855F7',
];

interface AddSubjectModalProps {
  onClose: () => void;
  onAdded: (subject: Subject) => void;
}

export default function AddSubjectModal({ onClose, onAdded }: AddSubjectModalProps) {
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState(PRESET_ICONS[0]);
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    if (!name.trim()) { setError('Please enter a subject name'); return; }
    if (name.trim().length > 30) { setError('Subject name too long (max 30 characters)'); return; }
    if (!user) { setError('Not signed in'); return; }

    setLoading(true);
    try {
      const newSubject = await createSubject(user.id, {
        name: name.trim(),
        color: selectedColor,
        icon: selectedIcon,
        noteCount: 0,
      });
      onAdded(newSubject);
      toast.success(`Subject "${newSubject.name}" created!`);
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to create subject');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
      <div className="w-full max-w-md animate-slide-up" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A', borderRadius: '20px' }}>
        <div className="flex items-center justify-between px-6 py-5" style={{ borderBottom: '1px solid #2A2A2A' }}>
          <div>
            <h2 className="text-lg font-bold text-white">Add Subject</h2>
            <p className="text-xs mt-0.5" style={{ color: '#B3B3B3' }}>Create a new subject folder</p>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#B3B3B3' }}>Subject Name</label>
            <input
              type="text"
              value={name}
              onChange={e => { setName(e.target.value); setError(''); }}
              placeholder="e.g. Biology, Mathematics..."
              autoFocus
              maxLength={30}
              className="input-dark w-full px-4 py-3 text-sm"
              style={error ? { borderColor: '#EF4444' } : {}}
              onKeyDown={e => e.key === 'Enter' && handleAdd()}
            />
            {error && <p className="text-xs mt-1.5" style={{ color: '#EF4444' }}>{error}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2.5" style={{ color: '#B3B3B3' }}>Choose Icon</label>
            <div className="grid grid-cols-8 gap-2">
              {PRESET_ICONS.map(icon => (
                <button
                  key={icon}
                  onClick={() => setSelectedIcon(icon)}
                  className="w-10 h-10 rounded-xl text-lg flex items-center justify-center transition-all"
                  style={{
                    background: selectedIcon === icon ? `${selectedColor}20` : '#121212',
                    border: `1px solid ${selectedIcon === icon ? selectedColor : '#2A2A2A'}`,
                    transform: selectedIcon === icon ? 'scale(1.1)' : 'scale(1)',
                  }}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2.5" style={{ color: '#B3B3B3' }}>Choose Color</label>
            <div className="flex flex-wrap gap-2.5">
              {PRESET_COLORS.map(color => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className="w-8 h-8 rounded-lg transition-all"
                  style={{
                    background: color,
                    transform: selectedColor === color ? 'scale(1.2)' : 'scale(1)',
                    outline: selectedColor === color ? `2px solid ${color}` : 'none',
                    outlineOffset: '2px',
                  }}
                />
              ))}
            </div>
          </div>

          <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: '#121212', border: '1px solid #2A2A2A' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0" style={{ background: `${selectedColor}15`, border: `1px solid ${selectedColor}30` }}>
              {selectedIcon}
            </div>
            <div>
              <p className="font-semibold text-sm text-white">{name.trim() || 'Subject Name'}</p>
              <p className="text-xs mt-0.5" style={{ color: '#666' }}>0 notes</p>
            </div>
          </div>
        </div>

        <div className="px-6 pb-6 flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl text-sm font-medium" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
            Cancel
          </button>
          <button
            onClick={handleAdd}
            disabled={!name.trim() || loading}
            className="flex-1 btn-orange py-3 text-sm flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Plus className="w-4 h-4" />Add Subject</>}
          </button>
        </div>
      </div>
    </div>
  );
}
