import { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Square, Play, Pause, Sparkles, Loader2, CheckCircle, FileText, AlertCircle, BookOpen, Brain, ClipboardList } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { saveNote, incrementSubjectNoteCount } from '@/lib/noteStorage';
import { getSubjects, type Subject } from '@/hooks/useAuth';
import { useAuth } from '@/hooks/useAuth';
import type { Note, Flashcard, QuizQuestion } from '@/types';

type RecordingState = 'idle' | 'recording' | 'paused' | 'processing' | 'done' | 'error';

export default function LiveCapturePanel() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [state, setState] = useState<RecordingState>('idle');
  const [elapsed, setElapsed] = useState(0);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [generatedNote, setGeneratedNote] = useState<Note | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [selectedSubjectId, setSelectedSubjectId] = useState('');
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [waveAmps] = useState(() => Array.from({ length: 20 }, (_, i) => (Math.sin(i * 0.5) + 1) / 2));

  const intervalRef = useRef<number | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const transcriptRef = useRef<HTMLDivElement>(null);
  const fullTranscriptRef = useRef('');

  useEffect(() => {
    if (user) {
      getSubjects(user.id).then(setSubjects).catch(console.error);
    }
  }, [user]);

  useEffect(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight;
    }
  }, [transcript, interimTranscript]);

  useEffect(() => {
    return () => {
      stopRecognition();
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const startRecognition = () => {
    const SpeechRecognition = (window as unknown as { SpeechRecognition?: typeof globalThis.SpeechRecognition; webkitSpeechRecognition?: typeof globalThis.SpeechRecognition }).SpeechRecognition
      || (window as unknown as { webkitSpeechRecognition?: typeof globalThis.SpeechRecognition }).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      toast.error('Speech recognition not supported. Please use Chrome or Edge.');
      return false;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        if (res.isFinal) {
          final += res[0].transcript + ' ';
        } else {
          interim += res[0].transcript;
        }
      }
      if (final) {
        fullTranscriptRef.current += final;
        setTranscript(fullTranscriptRef.current);
      }
      setInterimTranscript(interim);
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        toast.error('Microphone permission denied.');
        setState('idle');
      }
    };

    recognition.onend = () => {
      if (recognitionRef.current) {
        try { recognition.start(); } catch {}
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);
    return true;
  };

  const stopRecognition = () => {
    if (recognitionRef.current) {
      recognitionRef.current.onend = null;
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setIsListening(false);
    setInterimTranscript('');
  };

  const handleStart = () => {
    const ok = startRecognition();
    if (!ok) return;
    setState('recording');
    setElapsed(0);
    setTranscript('');
    setInterimTranscript('');
    fullTranscriptRef.current = '';
    toast.success('Recording started — speak clearly');
    intervalRef.current = window.setInterval(() => {
      setElapsed(prev => prev + 1);
    }, 1000);
  };

  const handlePause = () => {
    if (state === 'recording') {
      stopRecognition();
      if (intervalRef.current) clearInterval(intervalRef.current);
      setState('paused');
    } else {
      const ok = startRecognition();
      if (!ok) return;
      setState('recording');
      intervalRef.current = window.setInterval(() => {
        setElapsed(prev => prev + 1);
      }, 1000);
    }
  };

  const handleStop = async () => {
    stopRecognition();
    if (intervalRef.current) clearInterval(intervalRef.current);

    const capturedText = fullTranscriptRef.current.trim();
    if (!capturedText || capturedText.length < 20) {
      toast.error('Not enough speech captured. Please speak more before stopping.');
      setState('idle');
      return;
    }

    setState('processing');
    setErrorMsg('');
    const subjectObj = subjects.find(s => s.id === selectedSubjectId);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('generate-notes', {
        body: { text: capturedText, source: 'lecture', title: subjectObj?.name },
      });

      if (fnError) {
        let msg = fnError.message;
        if (fnError instanceof FunctionsHttpError) {
          try { msg = await fnError.context?.text() || msg; } catch { /* ignore */ }
        }
        throw new Error(msg);
      }

      if (!data?.success || !data?.data) throw new Error(data?.error || 'AI returned an unexpected response.');

      const aiData = data.data;

      const flashcards: Flashcard[] = (aiData.flashcards || []).map((fc: { front: string; back: string }, i: number) => ({
        id: `fc-${Date.now()}-${i}`, front: fc.front, back: fc.back,
      }));

      const quizQuestions: QuizQuestion[] = (aiData.quizQuestions || []).map((q: { type?: string; question: string; options?: string[]; correctAnswer: string; explanation: string }, i: number) => ({
        id: `q-${Date.now()}-${i}`, type: q.type || 'multiple-choice', question: q.question, options: q.options, correctAnswer: q.correctAnswer, explanation: q.explanation,
      }));

      const noteInput: Note = {
        id: '',
        title: aiData.title || (subjectObj ? `${subjectObj.name} Lecture` : 'Live Lecture Notes'),
        subject: subjectObj?.name || 'General',
        subjectId: selectedSubjectId || '',
        content: { sections: aiData.sections || [] },
        tags: [],
        source: 'lecture',
        summary: aiData.summary || '',
        flashcards,
        quizQuestions,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (!user) throw new Error('Not signed in.');
      const saved = await saveNote(user.id, noteInput);
      if (selectedSubjectId) await incrementSubjectNoteCount(selectedSubjectId);

      setGeneratedNote(saved);
      setState('done');
      toast.success('Lecture notes generated!');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Generation failed.';
      setErrorMsg(msg);
      setState('error');
      toast.error(msg);
    }
  };

  const handleReset = () => {
    setState('idle');
    setElapsed(0);
    setTranscript('');
    setInterimTranscript('');
    setGeneratedNote(null);
    setErrorMsg('');
    fullTranscriptRef.current = '';
  };

  const isRecordingOrPaused = state === 'recording' || state === 'paused';

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-2">Live Lecture Capture</h2>
        <p style={{ color: '#B3B3B3' }}>Record your lecture in real-time — AI converts speech to structured notes, flashcards &amp; quizzes</p>
      </div>

      {/* Subject selector */}
      <div className="mb-6">
        <label className="block text-sm font-medium mb-2" style={{ color: '#B3B3B3' }}>
          Subject <span style={{ color: '#666' }}>(optional)</span>
        </label>
        <select
          className="input-dark w-full px-4 py-3 text-sm"
          value={selectedSubjectId}
          onChange={e => setSelectedSubjectId(e.target.value)}
          disabled={isRecordingOrPaused || state === 'processing'}
        >
          <option value="">— No subject —</option>
          {subjects.map(s => <option key={s.id} value={s.id}>{s.icon} {s.name}</option>)}
        </select>
      </div>

      {/* Recorder Card */}
      <div className="card-dark p-8 text-center mb-6">
        {/* Waveform animation */}
        <div className="flex items-center justify-center gap-1 h-14 mb-6">
          {waveAmps.map((amp, i) => (
            <div
              key={i}
              className="w-1.5 rounded-full transition-all duration-300"
              style={{
                height: (state === 'recording' && isListening) ? `${8 + amp * 40}px` : '4px',
                background: state === 'recording' ? `rgba(255, ${106 + i * 4}, 0, ${0.6 + amp * 0.4})` : '#2A2A2A',
                animation: (state === 'recording' && isListening) ? `wave ${0.5 + amp * 0.8}s ease-in-out infinite alternate` : 'none',
                animationDelay: `${i * 0.06}s`,
              }}
            />
          ))}
        </div>

        <div className="text-5xl font-mono font-bold mb-2" style={{ color: state === 'recording' ? '#FF6A00' : '#666' }}>
          {formatTime(elapsed)}
        </div>
        <p className="text-sm mb-8" style={{ color: '#666' }}>
          {state === 'idle' && 'Ready to record — press Start and speak'}
          {state === 'recording' && (isListening ? '● Live recording...' : 'Recording...')}
          {state === 'paused' && '⏸ Recording paused'}
          {state === 'processing' && 'AI is generating notes from your recording...'}
          {state === 'done' && '✓ Notes generated successfully!'}
          {state === 'error' && '✕ Generation failed'}
        </p>

        {state === 'idle' && (
          <button onClick={handleStart} className="btn-orange animate-pulse-glow flex items-center gap-2 mx-auto px-8">
            <Mic className="w-5 h-5" />
            Start Recording
          </button>
        )}

        {isRecordingOrPaused && (
          <div className="flex items-center gap-4 justify-center">
            <button onClick={handlePause} className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
              {state === 'recording' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {state === 'recording' ? 'Pause' : 'Resume'}
            </button>
            <button onClick={handleStop} className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium" style={{ background: 'rgba(239,68,68,0.15)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.3)' }}>
              <Square className="w-4 h-4 fill-current" />
              Stop & Generate Notes
            </button>
          </div>
        )}

        {state === 'processing' && (
          <div className="flex items-center gap-2 justify-center" style={{ color: '#FF6A00' }}>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="font-medium">Analyzing {formatTime(elapsed)} of lecture audio...</span>
          </div>
        )}

        {state === 'done' && generatedNote && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 justify-center mb-2">
              <CheckCircle className="w-5 h-5" style={{ color: '#22C55E' }} />
              <span className="font-medium text-white">{generatedNote.title}</span>
            </div>
            <p className="text-sm" style={{ color: '#666' }}>
              {generatedNote.content.sections.length} sections • {generatedNote.flashcards?.length || 0} flashcards • {generatedNote.quizQuestions?.length || 0} quiz questions
            </p>
            <div className="flex gap-3 justify-center flex-wrap">
              <button onClick={() => navigate(`/note/${generatedNote.id}`)} className="btn-orange flex items-center gap-2 text-sm">
                <BookOpen className="w-4 h-4" />
                View Notes
              </button>
              <button onClick={handleReset} className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
                Record Again
              </button>
            </div>
          </div>
        )}

        {state === 'error' && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 justify-center" style={{ color: '#EF4444' }}>
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{errorMsg}</span>
            </div>
            <button onClick={handleReset} className="btn-orange flex items-center gap-2 mx-auto text-sm">Try Again</button>
          </div>
        )}
      </div>

      {/* Browser support note */}
      <div className="mb-4 flex items-start gap-2 px-4 py-3 rounded-xl" style={{ background: 'rgba(255,106,0,0.06)', border: '1px solid rgba(255,106,0,0.15)' }}>
        <Mic className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: '#FF6A00' }} />
        <p className="text-xs leading-relaxed" style={{ color: '#B3B3B3' }}>
          Uses browser speech recognition (best in Chrome/Edge). Allow microphone access when prompted.
        </p>
      </div>

      {/* Live Transcript — always shown when recording or has content */}
      {(isRecordingOrPaused || transcript.length > 0 || state === 'done') && (
        <div className="card-dark p-5 mb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <MicOff className="w-4 h-4" style={{ color: '#FF6A00' }} />
              Live Transcript
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(255,106,0,0.1)', color: '#FF6A00' }}>
                {transcript.split(/\s+/).filter(Boolean).length} words
              </span>
            </h3>
            {state === 'recording' && (
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#EF4444' }} />
                <span className="text-xs" style={{ color: '#EF4444' }}>LIVE</span>
              </div>
            )}
            {(state === 'done' || state === 'paused') && (
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" style={{ color: '#22C55E' }} />
                <span className="text-xs" style={{ color: '#22C55E' }}>Complete</span>
              </div>
            )}
          </div>
          <div ref={transcriptRef} className="max-h-52 overflow-y-auto">
            {transcript || interimTranscript ? (
              <p className="text-sm leading-relaxed" style={{ color: '#E0E0E0' }}>
                {transcript}
                {interimTranscript && <span style={{ color: '#888' }}>{interimTranscript}</span>}
              </p>
            ) : (
              <p className="text-sm" style={{ color: '#666' }}>Waiting for speech... Start speaking clearly.</p>
            )}
          </div>
        </div>
      )}

      {/* AI Summary shown when processing is done */}
      {state === 'done' && generatedNote?.summary && (
        <div className="card-dark p-5 mb-4" style={{ border: '1px solid rgba(255,106,0,0.2)' }}>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4" style={{ color: '#FF6A00' }} />
            <span className="text-sm font-semibold" style={{ color: '#FF6A00' }}>AI Summary</span>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: '#E0E0E0' }}>{generatedNote.summary}</p>
        </div>
      )}

      {/* Stats when done */}
      {state === 'done' && generatedNote && (
        <div className="grid grid-cols-3 gap-3">
          <div className="card-dark p-4 text-center">
            <FileText className="w-5 h-5 mx-auto mb-1" style={{ color: '#FF6A00' }} />
            <p className="text-lg font-bold text-white">{generatedNote.content.sections.length}</p>
            <p className="text-xs" style={{ color: '#666' }}>Sections</p>
          </div>
          <div className="card-dark p-4 text-center">
            <Brain className="w-5 h-5 mx-auto mb-1" style={{ color: '#8B5CF6' }} />
            <p className="text-lg font-bold text-white">{generatedNote.flashcards?.length || 0}</p>
            <p className="text-xs" style={{ color: '#666' }}>Flashcards</p>
          </div>
          <div className="card-dark p-4 text-center">
            <ClipboardList className="w-5 h-5 mx-auto mb-1" style={{ color: '#3B82F6' }} />
            <p className="text-lg font-bold text-white">{generatedNote.quizQuestions?.length || 0}</p>
            <p className="text-xs" style={{ color: '#666' }}>Quiz Q's</p>
          </div>
        </div>
      )}
    </div>
  );
}
