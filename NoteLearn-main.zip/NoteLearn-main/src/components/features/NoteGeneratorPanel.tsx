import { useState, useEffect, useRef } from 'react';
import {
  FileText, Loader2, CheckCircle, Sparkles, X,
  AlertCircle, BookOpen, Brain, ClipboardList, RotateCcw, Copy,
  Check, ChevronLeft, ChevronRight, Minus, XCircle, ArrowRight,
  Play, Globe, Youtube, Save, Star, BookMarked, Clock
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { saveNote, incrementSubjectNoteCount } from '@/lib/noteStorage';
import { getSubjects, type Subject } from '@/hooks/useAuth';
import { useAuth } from '@/hooks/useAuth';
import type { Note, Flashcard, QuizQuestion, KeyMoment, Definition } from '@/types';

type InputMode = 'link' | 'text';
type ResultTab = 'summary' | 'keypoints' | 'definitions' | 'flashcards' | 'quiz' | 'moments';

// ─── Flashcard Viewer ─────────────────────────────────────────────────────────
function FlashcardViewer({ flashcards }: { flashcards: Flashcard[] }) {
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [results, setResults] = useState<Record<string, 'easy' | 'medium' | 'hard'>>({});
  const current = flashcards[index];
  const done = Object.keys(results).length === flashcards.length;

  const rate = (r: 'easy' | 'medium' | 'hard') => {
    setResults(prev => ({ ...prev, [current.id]: r }));
    if (index < flashcards.length - 1) { setIndex(i => i + 1); setFlipped(false); }
  };
  const reset = () => { setIndex(0); setFlipped(false); setResults({}); };

  if (done) {
    const easy = Object.values(results).filter(r => r === 'easy').length;
    const med = Object.values(results).filter(r => r === 'medium').length;
    const hard = Object.values(results).filter(r => r === 'hard').length;
    return (
      <div className="text-center py-10 animate-fade-in">
        <div className="text-5xl mb-4">🎉</div>
        <h3 className="text-xl font-bold text-white mb-3">Session Complete!</h3>
        <div className="flex items-center justify-center gap-4 mb-6">
          <span className="px-3 py-1.5 rounded-xl text-sm font-semibold" style={{ background: 'rgba(34,197,94,0.1)', color: '#22C55E' }}>{easy} Easy</span>
          <span className="px-3 py-1.5 rounded-xl text-sm font-semibold" style={{ background: 'rgba(245,158,11,0.1)', color: '#F59E0B' }}>{med} Medium</span>
          <span className="px-3 py-1.5 rounded-xl text-sm font-semibold" style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444' }}>{hard} Hard</span>
        </div>
        <button onClick={reset} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold mx-auto" style={{ background: 'rgba(255,106,0,0.15)', color: '#FF6A00', border: '1px solid rgba(255,106,0,0.3)' }}>
          <RotateCcw className="w-4 h-4" /> Study Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs mb-1" style={{ color: '#666' }}>
        <span>Card {index + 1} of {flashcards.length}</span>
        <span>{Math.round(((index) / flashcards.length) * 100)}% done</span>
      </div>
      <div className="w-full h-1 rounded-full" style={{ background: '#2A2A2A' }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(index / flashcards.length) * 100}%`, background: 'linear-gradient(90deg, #FF6A00, #FF8C00)' }} />
      </div>
      <div
        onClick={() => setFlipped(f => !f)}
        className="relative cursor-pointer rounded-2xl p-8 min-h-[180px] flex flex-col items-center justify-center text-center transition-all duration-300 select-none"
        style={{ background: flipped ? 'rgba(255,106,0,0.07)' : '#121212', border: `1px solid ${flipped ? 'rgba(255,106,0,0.35)' : '#2A2A2A'}` }}
      >
        <div className="absolute top-3 left-3">
          <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: flipped ? 'rgba(255,106,0,0.15)' : '#2A2A2A', color: flipped ? '#FF6A00' : '#666' }}>
            {flipped ? '💡 Answer' : '❓ Question'}
          </span>
        </div>
        <p className="text-base font-medium leading-relaxed mt-4" style={{ color: flipped ? '#FFFFFF' : '#C0C0C0' }}>
          {flipped ? current.back : current.front}
        </p>
        {!flipped && <p className="text-xs mt-3 opacity-50" style={{ color: '#B3B3B3' }}>Click to reveal answer</p>}
      </div>
      <div className="flex items-center justify-between gap-3">
        <button onClick={() => { if (index > 0) { setIndex(i => i - 1); setFlipped(false); } }} disabled={index === 0} className="w-9 h-9 rounded-xl flex items-center justify-center disabled:opacity-30" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
          <ChevronLeft className="w-4 h-4" />
        </button>
        {flipped ? (
          <div className="flex items-center gap-2 flex-1 justify-center">
            <button onClick={() => rate('hard')} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}>
              <XCircle className="w-3.5 h-3.5" /> Hard
            </button>
            <button onClick={() => rate('medium')} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: 'rgba(245,158,11,0.1)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.2)' }}>
              <Minus className="w-3.5 h-3.5" /> OK
            </button>
            <button onClick={() => rate('easy')} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium" style={{ background: 'rgba(34,197,94,0.1)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.2)' }}>
              <CheckCircle className="w-3.5 h-3.5" /> Easy
            </button>
          </div>
        ) : (
          <div className="flex-1 flex justify-center">
            <button onClick={() => setFlipped(true)} className="text-xs px-4 py-2 rounded-xl" style={{ background: '#1A1A1A', color: '#666', border: '1px solid #2A2A2A' }}>
              Tap card or click here to flip →
            </button>
          </div>
        )}
        <button onClick={() => { if (index < flashcards.length - 1) { setIndex(i => i + 1); setFlipped(false); } }} disabled={index === flashcards.length - 1} className="w-9 h-9 rounded-xl flex items-center justify-center disabled:opacity-30" style={{ background: '#2A2A2A', color: '#B3B3B3' }}>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// ─── Quiz Viewer ──────────────────────────────────────────────────────────────
function QuizViewer({ questions }: { questions: QuizQuestion[] }) {
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [shortAns, setShortAns] = useState('');
  const [showExp, setShowExp] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const current = questions[idx];

  const isCorrect = selected === current.correctAnswer ||
    (current.type === 'short-answer' && shortAns.toLowerCase().includes(current.correctAnswer.toLowerCase().split(',')[0].toLowerCase().trim()));

  const check = () => { setShowExp(true); if (isCorrect) setScore(s => s + 1); };
  const next = () => {
    if (idx < questions.length - 1) { setIdx(i => i + 1); setSelected(null); setShortAns(''); setShowExp(false); }
    else setFinished(true);
  };
  const reset = () => { setIdx(0); setSelected(null); setShortAns(''); setShowExp(false); setScore(0); setFinished(false); };

  const optStyle = (opt: string) => {
    if (!showExp) return selected === opt
      ? { background: 'rgba(255,106,0,0.12)', border: '1px solid rgba(255,106,0,0.5)', color: '#FFFFFF' }
      : { background: '#121212', border: '1px solid #2A2A2A', color: '#B3B3B3' };
    if (opt === current.correctAnswer) return { background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.4)', color: '#22C55E' };
    if (opt === selected && opt !== current.correctAnswer) return { background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.4)', color: '#EF4444' };
    return { background: '#121212', border: '1px solid #2A2A2A', color: '#444' };
  };

  if (finished) {
    const pct = Math.round((score / questions.length) * 100);
    return (
      <div className="text-center py-10 animate-fade-in">
        <div className="text-5xl mb-4">{pct === 100 ? '🏆' : pct >= 60 ? '✅' : '📚'}</div>
        <h3 className="text-xl font-bold text-white mb-1">{pct === 100 ? 'Perfect!' : pct >= 60 ? 'Great Job!' : 'Keep Studying!'}</h3>
        <p className="text-4xl font-black mb-1" style={{ color: '#FF6A00' }}>{score}/{questions.length}</p>
        <p className="text-sm mb-6" style={{ color: '#666' }}>{pct}% accuracy</p>
        <button onClick={reset} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold mx-auto" style={{ background: 'rgba(255,106,0,0.15)', color: '#FF6A00', border: '1px solid rgba(255,106,0,0.3)' }}>
          <RotateCcw className="w-4 h-4" /> Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs mb-1" style={{ color: '#666' }}>
        <span>Q{idx + 1} of {questions.length}</span>
        <span className="font-semibold" style={{ color: '#FF6A00' }}>Score: {score}</span>
      </div>
      <div className="w-full h-1 rounded-full" style={{ background: '#2A2A2A' }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${((idx + 1) / questions.length) * 100}%`, background: 'linear-gradient(90deg, #FF6A00, #FF8C00)' }} />
      </div>
      <div>
        <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: 'rgba(255,106,0,0.12)', color: '#FF6A00' }}>
          {current.type === 'multiple-choice' ? 'Multiple Choice' : 'Short Answer'}
        </span>
        <h3 className="text-base font-semibold text-white mt-3 mb-4 leading-relaxed">{current.question}</h3>
      </div>
      {current.type === 'multiple-choice' ? (
        <div className="space-y-2">
          {current.options?.map(opt => (
            <button key={opt} onClick={() => !showExp && setSelected(opt)} className="w-full text-left px-4 py-3 rounded-xl text-sm transition-all duration-200 flex items-center justify-between" style={optStyle(opt)}>
              <span className="font-medium">{opt}</span>
              {showExp && opt === current.correctAnswer && <CheckCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#22C55E' }} />}
              {showExp && opt === selected && opt !== current.correctAnswer && <XCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#EF4444' }} />}
            </button>
          ))}
        </div>
      ) : (
        <input type="text" value={shortAns} onChange={e => setShortAns(e.target.value)} disabled={showExp} placeholder="Type your answer..." className="input-dark w-full px-4 py-3 text-sm" onKeyDown={e => e.key === 'Enter' && !showExp && shortAns && check()} />
      )}
      {showExp && (
        <div className="p-4 rounded-xl animate-fade-in" style={{ background: isCorrect ? 'rgba(34,197,94,0.07)' : 'rgba(239,68,68,0.07)', border: `1px solid ${isCorrect ? 'rgba(34,197,94,0.25)' : 'rgba(239,68,68,0.25)'}` }}>
          <div className="flex items-center gap-2 mb-1.5">
            {isCorrect ? <CheckCircle className="w-4 h-4" style={{ color: '#22C55E' }} /> : <XCircle className="w-4 h-4" style={{ color: '#EF4444' }} />}
            <span className="text-sm font-semibold" style={{ color: isCorrect ? '#22C55E' : '#EF4444' }}>
              {isCorrect ? 'Correct!' : `Incorrect — ${current.correctAnswer}`}
            </span>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: '#B3B3B3' }}>{current.explanation}</p>
        </div>
      )}
      <div className="flex justify-end gap-3 pt-1">
        {!showExp ? (
          <button onClick={check} disabled={!selected && !shortAns} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed" style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)', color: '#fff' }}>
            Check Answer
          </button>
        ) : (
          <button onClick={next} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ background: 'linear-gradient(135deg, #FF6A00, #FF8C00)', color: '#fff' }}>
            {idx < questions.length - 1 ? 'Next' : 'See Results'} <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Key Points Viewer ────────────────────────────────────────────────────────
function KeyPointsViewer({ keyPoints }: { keyPoints: string[] }) {
  return (
    <div className="space-y-3 animate-fade-in">
      <div className="flex items-center gap-2 mb-4 px-1">
        <Star className="w-4 h-4" style={{ color: '#F59E0B' }} />
        <p className="text-sm font-semibold text-white">Most important takeaways from this material</p>
      </div>
      {keyPoints.map((point, i) => (
        <div key={i} className="flex items-start gap-4 p-4 rounded-xl transition-all" style={{ background: '#121212', border: '1px solid #2A2A2A' }}>
          <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-sm" style={{ background: 'rgba(245,158,11,0.12)', color: '#F59E0B' }}>
            {i + 1}
          </div>
          <p className="text-sm leading-relaxed flex-1 pt-0.5" style={{ color: '#D0D0D0' }}>{point}</p>
        </div>
      ))}
    </div>
  );
}

// ─── Definitions Viewer ───────────────────────────────────────────────────────
function DefinitionsViewer({ definitions }: { definitions: Definition[] }) {
  const [expanded, setExpanded] = useState<number | null>(null);
  return (
    <div className="space-y-2 animate-fade-in">
      <div className="flex items-center gap-2 mb-4 px-1">
        <BookMarked className="w-4 h-4" style={{ color: '#3B82F6' }} />
        <p className="text-sm font-semibold text-white">Key terms and definitions</p>
      </div>
      {definitions.map((def, i) => (
        <div
          key={i}
          className="rounded-xl overflow-hidden cursor-pointer transition-all"
          style={{ background: expanded === i ? 'rgba(59,130,246,0.06)' : '#121212', border: `1px solid ${expanded === i ? 'rgba(59,130,246,0.25)' : '#2A2A2A'}` }}
          onClick={() => setExpanded(expanded === i ? null : i)}
        >
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: expanded === i ? '#3B82F6' : '#444' }} />
            <span className="font-semibold text-sm flex-1" style={{ color: expanded === i ? '#FFFFFF' : '#C0C0C0' }}>{def.term}</span>
            <ChevronLeft className={`w-4 h-4 transition-transform flex-shrink-0 ${expanded === i ? '-rotate-90' : 'rotate-180'}`} style={{ color: '#555' }} />
          </div>
          {expanded === i && (
            <div className="px-4 pb-4 pt-0">
              <div className="ml-5 pl-4 text-sm leading-relaxed" style={{ color: '#B3B3B3', borderLeft: '2px solid rgba(59,130,246,0.3)' }}>
                {def.definition}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Key Moments Viewer ───────────────────────────────────────────────────────
function KeyMomentsViewer({ moments, videoUrl }: { moments: KeyMoment[]; videoUrl?: string }) {
  const getVideoId = (url: string) => {
    const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    return m?.[1] || null;
  };

  const timestampToSeconds = (ts: string) => {
    const parts = ts.replace(/[\[\]]/g, '').split(':').map(Number);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return 0;
  };

  const videoId = videoUrl ? getVideoId(videoUrl) : null;

  return (
    <div className="space-y-3 animate-fade-in">
      <div className="flex items-center gap-2 mb-4 px-1">
        <Clock className="w-4 h-4" style={{ color: '#EF4444' }} />
        <p className="text-sm font-semibold text-white">Key moments in the video</p>
      </div>
      {/* Timeline */}
      <div className="relative">
        <div className="absolute left-[22px] top-0 bottom-0 w-0.5" style={{ background: 'linear-gradient(to bottom, rgba(239,68,68,0.5), rgba(239,68,68,0.05))' }} />
        <div className="space-y-4">
          {moments.map((moment, i) => {
            const seconds = timestampToSeconds(moment.timestamp);
            const ytUrl = videoId ? `https://www.youtube.com/watch?v=${videoId}&t=${seconds}s` : null;
            return (
              <div key={i} className="flex items-start gap-4 relative">
                {/* Timeline dot */}
                <div className="w-11 flex-shrink-0 flex items-start justify-center pt-1 relative z-10">
                  <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: '#0B0B0B', border: '2px solid #EF4444' }}>
                    <div className="w-2 h-2 rounded-full" style={{ background: '#EF4444' }} />
                  </div>
                </div>
                <div className="flex-1 rounded-xl p-4 transition-all" style={{ background: '#121212', border: '1px solid #2A2A2A' }}>
                  <div className="flex items-center justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold px-2 py-0.5 rounded-md font-mono" style={{ background: 'rgba(239,68,68,0.12)', color: '#EF4444' }}>
                        {moment.timestamp}
                      </span>
                      <span className="text-sm font-semibold text-white">{moment.topic}</span>
                    </div>
                    {ytUrl && (
                      <a
                        href={ytUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg flex-shrink-0 transition-all hover:opacity-80"
                        style={{ background: 'rgba(239,68,68,0.08)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}
                        onClick={e => e.stopPropagation()}
                      >
                        <Youtube className="w-3 h-3" />
                        Watch
                      </a>
                    )}
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: '#B3B3B3' }}>{moment.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Main Panel ───────────────────────────────────────────────────────────────
const MODES: { id: InputMode; label: string; icon: React.ElementType; desc: string; color: string; placeholder?: string }[] = [
  { id: 'link', label: 'Link Analyzer', icon: Globe, desc: 'Any website or article URL', color: '#3B82F6', placeholder: 'https://example.com/article' },
  { id: 'text', label: 'Paste Text', icon: FileText, desc: 'Any study material', color: '#8B5CF6' },
];

const STEPS_DEFAULT = [
  'Reading your material...',
  'Extracting key concepts...',
  'Building definitions glossary...',
  'Generating flashcards...',
  'Creating quiz questions...',
];

interface AIResult {
  title: string;
  summary: string;
  sections: { heading: string; points: string[] }[];
  flashcards: Flashcard[];
  quizQuestions: QuizQuestion[];
  keyPoints: string[];
  definitions: Definition[];
  keyMoments?: KeyMoment[];
}

export default function NoteGeneratorPanel() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<InputMode>('link');
  const [url, setUrl] = useState('');
  const [pastedText, setPastedText] = useState('');
  const [generating, setGenerating] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [activeSteps, setActiveSteps] = useState<string[]>(STEPS_DEFAULT);
  const [result, setResult] = useState<AIResult | null>(null);
  const [savedNote, setSavedNote] = useState<Note | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState('');
  const [error, setError] = useState('');
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [activeTab, setActiveTab] = useState<ResultTab>('summary');
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (user) getSubjects(user.id).then(setSubjects).catch(console.error);
  }, [user]);

  const resetInput = () => {
    setUrl(''); setPastedText('');
    setError(''); setResult(null); setSavedNote(null); setActiveTab('summary');
    setCurrentUrl('');
  };

  const startSteps = (steps: string[]) => {
    setActiveSteps(steps);
    let s = 0; setStepIndex(0);
    timerRef.current = window.setInterval(() => { s++; if (s < steps.length) setStepIndex(s); }, 1800);
  };
  const stopSteps = () => { if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; } };

  const handleGenerate = async () => {
    setError(''); setResult(null); setSavedNote(null);
    const subjectObj = subjects.find(s => s.id === selectedSubjectId);
    let bodyPayload: Record<string, string> = {};
    const capturedUrl = url.trim();

    try {
      if (mode === 'text') {
        if (pastedText.trim().length < 20) throw new Error('Please paste at least 20 characters of text.');
        bodyPayload = { text: pastedText.trim(), source: 'text' };
      } else if (mode === 'link') {
        if (!capturedUrl) throw new Error('Please enter a URL.');
        bodyPayload = { text: `Analyzing: ${capturedUrl}`, source: 'url', url: capturedUrl };
      }

      if (subjectObj?.name) bodyPayload.title = subjectObj.name;

      setCurrentUrl(capturedUrl);
      setGenerating(true);
      startSteps(STEPS_DEFAULT);

      const { data, error: fnError } = await supabase.functions.invoke('generate-notes', { body: bodyPayload });
      stopSteps();

      if (fnError) {
        let msg = fnError.message;
        if (fnError instanceof FunctionsHttpError) {
          try { const t = await fnError.context?.text(); msg = t || msg; } catch { /* */ }
        }
        throw new Error(msg);
      }

      if (!data?.success || !data?.data) throw new Error(data?.error || 'Unexpected AI response.');

      const aiData = data.data;
      const flashcards: Flashcard[] = (aiData.flashcards || []).map((fc: { front: string; back: string }, i: number) => ({
        id: `fc-${Date.now()}-${i}`, front: fc.front, back: fc.back,
      }));
      const quizQuestions: QuizQuestion[] = (aiData.quizQuestions || []).map((q: { type?: string; question: string; options?: string[]; correctAnswer: string; explanation: string }, i: number) => ({
        id: `q-${Date.now()}-${i}`, type: q.type || 'multiple-choice', question: q.question, options: q.options, correctAnswer: q.correctAnswer, explanation: q.explanation,
      }));

      setResult({
        title: aiData.title,
        summary: aiData.summary,
        sections: aiData.sections || [],
        flashcards,
        quizQuestions,
        keyPoints: aiData.keyPoints || [],
        definitions: aiData.definitions || [],
        keyMoments: aiData.keyMoments || [],
      });
      toast.success('Analysis complete!');
    } catch (err) {
      stopSteps();
      const msg = err instanceof Error ? err.message : 'Something went wrong.';
      setError(msg);
      toast.error(msg);
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!result || !user) return;
    setSaving(true);
    try {
      const subjectObj = subjects.find(s => s.id === selectedSubjectId);
      const sourceMap: Record<InputMode, Note['source']> = { link: 'youtube', text: 'text' };
      const noteInput: Note = {
        id: '', title: result.title, subject: subjectObj?.name || 'General',
        subjectId: selectedSubjectId || '', content: { sections: result.sections },
        tags: [], source: sourceMap[mode], summary: result.summary,
        flashcards: result.flashcards, quizQuestions: result.quizQuestions,
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      };
      const saved = await saveNote(user.id, noteInput);
      if (selectedSubjectId) await incrementSubjectNoteCount(selectedSubjectId);
      setSavedNote(saved);
      toast.success('Saved to your notes!');
    } catch {
      toast.error('Failed to save note.');
    } finally {
      setSaving(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    const text = [
      `# ${result.title}`,
      `\n## Summary\n${result.summary}`,
      result.keyPoints.length > 0 ? `\n## Key Points\n${result.keyPoints.map(p => `• ${p}`).join('\n')}` : '',
      ...result.sections.map(s => `\n## ${s.heading}\n${s.points.map(p => `• ${p}`).join('\n')}`),
    ].filter(Boolean).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const canGenerate = () => {
    if (generating) return false;
    if (mode === 'text') return pastedText.trim().length > 20;
    if (mode === 'link') return url.trim().length > 5;
    return false;
  };

  // Build tabs dynamically based on available content
  const buildTabs = (r: AIResult, _isYoutube: boolean) => {
    const tabs: { id: ResultTab; icon: React.ElementType; label: string; color: string; count?: number }[] = [
      { id: 'summary', icon: FileText, label: 'Notes', color: '#FF6A00' },
    ];
    if (r.keyPoints?.length > 0) tabs.push({ id: 'keypoints', icon: Star, label: `Key Points`, color: '#F59E0B', count: r.keyPoints.length });
    if (r.definitions?.length > 0) tabs.push({ id: 'definitions', icon: BookMarked, label: `Definitions`, color: '#3B82F6', count: r.definitions.length });
    if (isYoutube && r.keyMoments && r.keyMoments.length > 0) tabs.push({ id: 'moments', icon: Clock, label: `Moments`, color: '#EF4444', count: r.keyMoments.length });
    if (r.flashcards?.length > 0) tabs.push({ id: 'flashcards', icon: Brain, label: `Flashcards`, color: '#8B5CF6', count: r.flashcards.length });
    if (r.quizQuestions?.length > 0) tabs.push({ id: 'quiz', icon: ClipboardList, label: `Quiz`, color: '#22C55E', count: r.quizQuestions.length });
    return tabs;
  };

  const currentMode = MODES.find(m => m.id === mode)!;
  const tabs = result ? buildTabs(result, false) : [];

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-2">AI Study Analyzer</h2>
        <p style={{ color: '#B3B3B3' }}>Upload PDFs, paste YouTube links, or drop any text — get notes, key points, definitions, flashcards &amp; quizzes instantly.</p>
      </div>

      {/* Mode Selector */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {MODES.map(m => (
          <button
            key={m.id}
            onClick={() => { setMode(m.id); resetInput(); }}
            className="p-4 rounded-xl text-left transition-all duration-200"
            style={{
              background: mode === m.id ? `${m.color}12` : '#1A1A1A',
              border: `1px solid ${mode === m.id ? `${m.color}45` : '#2A2A2A'}`,
            }}
          >
            <m.icon className="w-5 h-5 mb-2" style={{ color: mode === m.id ? m.color : '#555' }} />
            <p className="text-sm font-semibold" style={{ color: mode === m.id ? '#FFFFFF' : '#888' }}>{m.label}</p>
            <p className="text-xs mt-0.5" style={{ color: '#555' }}>{m.desc}</p>
          </button>
        ))}
      </div>

      {/* Input Area */}
      <div className="mb-6">
        {mode === 'link' && (
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#B3B3B3' }}>Website URL</label>
            <div className="relative">
              <currentMode.icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#666' }} />
              <input
                type="url"
                value={url}
                onChange={e => setUrl(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && canGenerate() && handleGenerate()}
                placeholder={currentMode.placeholder}
                className="input-dark w-full pl-10 pr-4 py-3 text-sm"
              />
            </div>
          </div>
        )}

        {mode === 'text' && (
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#B3B3B3' }}>Study Material</label>
            <textarea
              value={pastedText}
              onChange={e => setPastedText(e.target.value)}
              placeholder="Paste your study material here — lecture notes, textbook excerpts, article text, etc."
              className="input-dark w-full px-4 py-3 text-sm resize-none"
              rows={7}
              style={{ lineHeight: '1.6' }}
            />
            <p className="text-xs mt-1.5" style={{ color: '#555' }}>{pastedText.length} characters</p>
          </div>
        )}


      </div>

      {/* Subject + Generate */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <select className="input-dark flex-1 px-4 py-3 text-sm" value={selectedSubjectId} onChange={e => setSelectedSubjectId(e.target.value)}>
          <option value="">— No subject —</option>
          {subjects.map(s => <option key={s.id} value={s.id}>{s.icon} {s.name}</option>)}
        </select>
        {!generating && !result && (
          <button
            onClick={handleGenerate}
            disabled={!canGenerate()}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            style={{
              background: canGenerate() ? 'linear-gradient(135deg, #FF6A00, #FF8C00)' : '#2A2A2A',
              color: '#fff',
              boxShadow: canGenerate() ? '0 0 24px rgba(255,106,0,0.35)' : 'none',
            }}
          >
            <Play className="w-4 h-4" />
            Analyze
          </button>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="mb-4 flex items-start gap-3 px-4 py-3 rounded-xl" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)' }}>
          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: '#EF4444' }} />
          <p className="text-sm" style={{ color: '#EF4444' }}>{error}</p>
        </div>
      )}

      {/* Loading */}
      {generating && (
        <div className="rounded-2xl p-6 animate-fade-in" style={{ background: '#121212', border: '1px solid #2A2A2A' }}>
          <div className="flex items-center gap-3 mb-5">
            <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#FF6A00' }} />
            <span className="font-semibold text-white">AI is analyzing your content...</span>
          </div>
          <div className="space-y-3">
            {activeSteps.map((step, i) => (
              <div key={i} className="flex items-center gap-3">
                {i < stepIndex ? (
                  <CheckCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#22C55E' }} />
                ) : i === stepIndex ? (
                  <Loader2 className="w-4 h-4 animate-spin flex-shrink-0" style={{ color: '#FF6A00' }} />
                ) : (
                  <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ background: '#2A2A2A' }} />
                )}
                <span className="text-sm transition-all" style={{ color: i <= stepIndex ? '#E0E0E0' : '#444' }}>{step}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {result && !generating && (
        <div className="rounded-2xl overflow-hidden animate-slide-up" style={{ border: '1px solid #2A2A2A' }}>
          {/* Result Header */}
          <div className="px-6 py-5" style={{ background: '#1A1A1A', borderBottom: '1px solid #2A2A2A' }}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#22C55E' }} />
                  <span className="text-xs font-semibold" style={{ color: '#22C55E' }}>Analysis Complete</span>
                </div>
                <h3 className="font-bold text-white text-base truncate">{result.title}</h3>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(255,106,0,0.1)', color: '#FF6A00' }}>{result.sections.length} sections</span>
                  {result.keyPoints?.length > 0 && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(245,158,11,0.1)', color: '#F59E0B' }}>{result.keyPoints.length} key points</span>}
                  {result.definitions?.length > 0 && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(59,130,246,0.1)', color: '#3B82F6' }}>{result.definitions.length} definitions</span>}
                  {result.keyMoments && result.keyMoments.length > 0 && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(239,68,68,0.1)', color: '#EF4444' }}>{result.keyMoments.length} moments</span>}
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(139,92,246,0.1)', color: '#8B5CF6' }}>{result.flashcards.length} flashcards</span>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(34,197,94,0.1)', color: '#22C55E' }}>{result.quizQuestions.length} quiz Q's</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button onClick={handleCopy} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all" style={{ background: '#2A2A2A', color: copied ? '#22C55E' : '#B3B3B3' }} title="Copy notes">
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button onClick={handleGenerate} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all" style={{ background: '#2A2A2A', color: '#B3B3B3' }} title="Regenerate">
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                {!savedNote ? (
                  <button onClick={handleSave} disabled={saving} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all disabled:opacity-60" style={{ background: 'rgba(255,106,0,0.15)', color: '#FF6A00', border: '1px solid rgba(255,106,0,0.3)' }}>
                    {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
                    Save
                  </button>
                ) : (
                  <button onClick={() => navigate(`/note/${savedNote.id}`)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: 'rgba(34,197,94,0.12)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.3)' }}>
                    <BookOpen className="w-3 h-3" />
                    View Note
                  </button>
                )}
                <button onClick={() => { setResult(null); setSavedNote(null); resetInput(); }} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#2A2A2A', color: '#666' }} title="Analyze new content">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex overflow-x-auto" style={{ background: '#121212', borderBottom: '1px solid #2A2A2A' }}>
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="flex items-center gap-1.5 px-4 py-3 text-sm font-medium transition-all border-b-2 flex-shrink-0"
                style={{
                  borderBottomColor: activeTab === tab.id ? tab.color : 'transparent',
                  color: activeTab === tab.id ? tab.color : '#555',
                  background: activeTab === tab.id ? `${tab.color}08` : 'transparent',
                }}
              >
                <tab.icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className="text-xs px-1.5 py-0.5 rounded-full font-bold" style={{ background: activeTab === tab.id ? `${tab.color}20` : '#2A2A2A', color: activeTab === tab.id ? tab.color : '#555' }}>
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="p-6" style={{ background: '#0F0F0F' }}>
            {/* NOTES / SUMMARY TAB */}
            {activeTab === 'summary' && (
              <div className="space-y-5 animate-fade-in">
                {result.summary && (
                  <div className="p-4 rounded-xl" style={{ background: 'rgba(255,106,0,0.05)', border: '1px solid rgba(255,106,0,0.15)' }}>
                    <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#FF6A00' }}>📌 Overview</p>
                    <p className="text-sm leading-relaxed" style={{ color: '#C0C0C0' }}>{result.summary}</p>
                  </div>
                )}
                {result.sections.map((section, i) => (
                  <div key={i}>
                    <h4 className="font-bold text-white mb-3 flex items-center gap-2">
                      <span className="w-5 h-5 rounded-md flex items-center justify-center text-xs font-bold flex-shrink-0" style={{ background: 'rgba(255,106,0,0.15)', color: '#FF6A00' }}>{i + 1}</span>
                      {section.heading}
                    </h4>
                    <ul className="space-y-2">
                      {section.points.map((pt, j) => (
                        <li key={j} className="flex items-start gap-2.5 text-sm" style={{ color: '#B3B3B3' }}>
                          <span className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: '#FF6A00' }} />
                          {pt}
                        </li>
                      ))}
                    </ul>
                    {i < result.sections.length - 1 && <div className="mt-5" style={{ borderBottom: '1px solid #1E1E1E' }} />}
                  </div>
                ))}
              </div>
            )}

            {/* KEY POINTS TAB */}
            {activeTab === 'keypoints' && (
              <KeyPointsViewer keyPoints={result.keyPoints} />
            )}

            {/* DEFINITIONS TAB */}
            {activeTab === 'definitions' && (
              <DefinitionsViewer definitions={result.definitions} />
            )}

            {/* KEY MOMENTS TAB (YouTube) */}
            {activeTab === 'moments' && result.keyMoments && result.keyMoments.length > 0 && (
              <KeyMomentsViewer moments={result.keyMoments} videoUrl={currentUrl} />
            )}

            {/* FLASHCARDS TAB */}
            {activeTab === 'flashcards' && (
              <div className="animate-fade-in">
                {result.flashcards.length > 0 ? (
                  <FlashcardViewer flashcards={result.flashcards} />
                ) : (
                  <div className="text-center py-10" style={{ color: '#555' }}>
                    <Brain className="w-10 h-10 mx-auto mb-3 opacity-30" />
                    <p>No flashcards generated.</p>
                  </div>
                )}
              </div>
            )}

            {/* QUIZ TAB */}
            {activeTab === 'quiz' && (
              <div className="animate-fade-in">
                {result.quizQuestions.length > 0 ? (
                  <QuizViewer questions={result.quizQuestions} />
                ) : (
                  <div className="text-center py-10" style={{ color: '#555' }}>
                    <ClipboardList className="w-10 h-10 mx-auto mb-3 opacity-30" />
                    <p>No quiz questions generated.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
