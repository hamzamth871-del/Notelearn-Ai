import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  MessageSquare,
  Plus,
  LogOut,
  Camera,
  Brain,
  Settings,
} from 'lucide-react';
import logo from '@/assets/logo.png';
import { useAuth, getSubjects, type Subject } from '@/hooks/useAuth';
import AddSubjectModal from '@/components/features/AddSubjectModal';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

interface SidebarProps {
  collapsed?: boolean;
  onSubjectChange?: () => void;
}

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
  { icon: MessageSquare, label: 'AI Chat', path: '/chat' },
  { icon: Brain, label: 'Study Mode', path: '/study' },
];

export default function Sidebar({ collapsed = false, onSubjectChange }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signOut, updateAvatar } = useAuth();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [showAddSubject, setShowAddSubject] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  useEffect(() => {
    if (user) {
      getSubjects(user.id).then(setSubjects).catch(console.error);
    }
  }, [user]);

  const handleSubjectAdded = async () => {
    if (user) {
      const updated = await getSubjects(user.id);
      setSubjects(updated);
      onSubjectChange?.();
    }
  };

  const isActive = (path: string) => {
    if (path === '/dashboard' && location.pathname === '/dashboard') return true;
    if (path === '/chat' && location.pathname === '/chat') return true;
    if (path === '/study' && location.pathname === '/study') return true;
    return false;
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 2 * 1024 * 1024) { toast.error('Image too large (max 2MB)'); return; }

    setUploadingAvatar(true);
    try {
      const ext = file.name.split('.').pop();
      const path = `${user.id}/avatar.${ext}`;
      const { error: uploadError } = await supabase.storage.from('avatars').upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path);
      await updateAvatar(publicUrl + `?t=${Date.now()}`);
      toast.success('Profile picture updated!');
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploadingAvatar(false);
    }
  };

  return (
    <>
      <aside className="flex flex-col h-full" style={{ background: '#0B0B0B', borderRight: '1px solid #2A2A2A' }}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 cursor-pointer" onClick={() => navigate('/')}>
          <img src={logo} alt="NoteLearn" className="w-9 h-9 rounded-xl object-cover flex-shrink-0" />
          {!collapsed && <span className="text-lg font-bold text-white">NoteLearn</span>}
        </div>

        {/* Nav */}
        <div className="flex-1 overflow-y-auto px-3 py-2">
          {!collapsed && (
            <p className="px-3 py-2 text-xs font-semibold uppercase tracking-widest" style={{ color: '#444' }}>
              Navigation
            </p>
          )}

          {navItems.map(item => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`sidebar-item w-full text-left mb-1 ${isActive(item.path) ? 'active' : ''}`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </button>
          ))}

          {/* Subjects */}
          {!collapsed && (
            <>
              <div className="mt-6 mb-2 flex items-center justify-between px-3">
                <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#444' }}>Subjects</p>
                <button
                  onClick={() => setShowAddSubject(true)}
                  className="w-6 h-6 rounded-md flex items-center justify-center transition-colors hover:bg-orange-500/20"
                  style={{ color: '#FF6A00' }}
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {subjects.length === 0 ? (
                <button
                  onClick={() => setShowAddSubject(true)}
                  className="w-full flex items-center gap-2 px-3 py-3 rounded-xl text-sm transition-all border-dashed"
                  style={{ border: '1px dashed #2A2A2A', color: '#444' }}
                >
                  <Plus className="w-4 h-4" />
                  <span>Add your first subject</span>
                </button>
              ) : (
                <div className="space-y-1">
                  {subjects.map(subject => (
                    <button
                      key={subject.id}
                      onClick={() => navigate(`/dashboard?subject=${subject.id}`)}
                      className="sidebar-item w-full text-left"
                    >
                      <span className="text-base">{subject.icon}</span>
                      <span className="flex-1 truncate">{subject.name}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full flex-shrink-0" style={{ background: `${subject.color}20`, color: subject.color }}>
                        {subject.noteCount}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Bottom: user */}
        {!collapsed && user && (
          <div className="px-3 pb-4">
            <div className="rounded-xl p-3" style={{ background: '#1A1A1A', border: '1px solid #2A2A2A' }}>
              <div className="flex items-center gap-3">
                {/* Avatar with upload */}
                <div className="relative flex-shrink-0">
                  <label className="cursor-pointer">
                    <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
                    <div className="relative w-9 h-9">
                      <img
                        src={user.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}&backgroundColor=FF6A00&textColor=ffffff`}
                        alt={user.name}
                        className="w-9 h-9 rounded-lg object-cover"
                      />
                      <div
                        className="absolute inset-0 rounded-lg flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                        style={{ background: 'rgba(0,0,0,0.5)' }}
                      >
                        {uploadingAvatar
                          ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          : <Camera className="w-3 h-3 text-white" />
                        }
                      </div>
                    </div>
                  </label>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{user.name}</p>
                  <p className="text-xs truncate" style={{ color: '#666' }}>{user.email}</p>
                </div>
                <button
                  onClick={() => navigate('/profile')}
                  className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors hover:bg-orange-500/20"
                  style={{ color: '#666' }}
                  title="Profile settings"
                >
                  <Settings className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleSignOut}
                  className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors hover:bg-red-500/20"
                  style={{ color: '#666' }}
                  title="Sign out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </aside>

      {showAddSubject && (
        <AddSubjectModal onClose={() => setShowAddSubject(false)} onAdded={handleSubjectAdded} />
      )}
    </>
  );
}
